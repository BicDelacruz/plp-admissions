<?php
// ============================================================
// config/app.php
// Application-wide constants
// ============================================================

// -- Load .env file (local secrets) ------------------------------
(function () {
    $envFile = dirname(__DIR__) . '/.env';
    if (!file_exists($envFile)) return;
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;
        if (strpos($line, '=') === false) continue;
        [$key, $val] = explode('=', $line, 2);
        $key = trim($key);
        $val = trim($val);
        if (!getenv($key)) {
            putenv("$key=$val");
        }
    }
})();

// -- Environment -------------------------------------------------
define('APP_ENV', getenv('APP_ENV') ?: 'development');   // 'development' | 'production'
define('APP_DEBUG', APP_ENV === 'development');

// -- Paths -------------------------------------------------------
define('ROOT_PATH',   dirname(__DIR__));
define('CONFIG_PATH', ROOT_PATH . '/config');
define('CORE_PATH',   ROOT_PATH . '/core');
define('MODULES_PATH',ROOT_PATH . '/modules');
define('VIEWS_PATH',  ROOT_PATH . '/views');
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('UPLOAD_PATH', PUBLIC_PATH . '/uploads');

// -- URL ---------------------------------------------------------
if (APP_ENV === 'production') {
    define('BASE_URL', rtrim(getenv('APP_URL') ?: 'https://plp-admissions.vercel.app', '/'));
} else {
    $__forwarded = $_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '';
    $__scheme = ($__forwarded === 'https'
        || (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'))
        ? 'https' : 'http';
    $__host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $__script = $_SERVER['SCRIPT_NAME'] ?? '/plp-admissions/public/index.php';
    $__base   = rtrim(dirname(dirname($__script)), '/\\');
    define('BASE_URL', $__scheme . '://' . $__host . $__base . '/public');
    unset($__scheme, $__host, $__script, $__base);
}

// -- Session -----------------------------------------------------
define('SESSION_NAME',    'plp_session');
define('SESSION_LIFETIME_STUDENT', 1800);   // 30 min
define('SESSION_LIFETIME_STAFF',   7200);   // 2 hours
define('SESSION_WARN_BEFORE',       300);   // warn 5 min before expiry

// -- File uploads ------------------------------------------------
// Vercel caps request bodies at 4.5 MB, so the document limit is 4 MB.
define('MAX_UPLOAD_BYTES', 4 * 1024 * 1024);
define('ALLOWED_MIME_TYPES', ['application/pdf', 'image/jpeg', 'image/png', 'image/webp']);

// -- Supabase Storage --------------------------------------------
define('SUPABASE_URL',              getenv('SUPABASE_URL')              ?: '');
define('SUPABASE_SERVICE_KEY',      getenv('SUPABASE_SERVICE_KEY')      ?: '');
define('SUPABASE_BUCKET_DOCUMENTS', getenv('SUPABASE_BUCKET_DOCUMENTS') ?: 'documents');
define('SUPABASE_BUCKET_BRANDING',  getenv('SUPABASE_BUCKET_BRANDING')  ?: 'branding');

// -- AI document sorting (local model PC through a Cloudflare Tunnel) --
// Empty AI_MODEL_URL = AI off; uploads use the category dropdown.
define('AI_MODEL_URL', getenv('AI_MODEL_URL') ?: '');
// Capped at 25 s: the Vercel function dies at 60 s, and a dead function shows the applicant an error
// instead of the "pick the document type" fallback. A bigger value in Vercel is ignored.
define('AI_TIMEOUT',   max(5, min(25, (int) (getenv('AI_TIMEOUT') ?: 25))));
define('AI_MODEL_KEY', getenv('AI_MODEL_KEY') ?: '');

// -- Roles -------------------------------------------------------
// DB enum values stored on users.role:
//   'student' | 'staff' | 'proctor' | 'sso' | 'dean' | 'admin'
//
// ROLE_STAFF is the legacy 'staff' enum value — used for faculty who
// conduct interviews ("Professor" is the user-facing label).
// ROLE_PROCTOR is a new role for faculty who proctor exams.
// SSO and Dean are top-level roles for the role-redesign rollout.
define('ROLE_STUDENT',   'student');
define('ROLE_STAFF',     'staff');
define('ROLE_PROFESSOR', 'staff');     // alias — DB enum stays 'staff'
define('ROLE_PROCTOR',   'proctor');
define('ROLE_SSO',       'sso');
define('ROLE_DEAN',      'dean');
define('ROLE_ADMIN',     'admin');

// -- Applicant types ---------------------------------------------
define('TYPE_FRESHMAN',   'freshman');
define('TYPE_TRANSFEREE', 'transferee');
define('TYPE_FOREIGN',    'foreign');

// ----------------------------------------------------------------
// OFFICIAL PLP DOCUMENTARY REQUIREMENTS
// Source: Pamantasan ng Lungsod ng Pasig Admission Requirements
// ----------------------------------------------------------------

// -- Documents shared by BOTH freshmen and transferees -----------
// Conditional slots (see DOCS_CONDITIONAL) are only required when the applicant ticks the flag.
define('DOCS_CORE', [
    'psa_birth_cert'         => 'PSA Birth Certificate (second page or notation, if needed)',
    'marriage_cert'          => 'Marriage Certificate (if married)',
    'valid_id_1'             => 'Valid Government-issued ID (front and back)',
    'barangay_cert'          => 'Barangay Certificate of Residence',
    'guardianship_affidavit' => 'Affidavit of Guardianship or Support (if not living with parents)',
    'photo_1'                => 'Passport-size Photo, white background with nameplate',
]);

// -- Freshman-only docs ------------------------------------------
// Form 138 is for currently Grade 12; Form 137 (or Grade 12 Form 138) is for SHS graduates.
define('DOCS_FRESHMAN', [
    'form_138'           => 'CTC of Form 138 (Grade 11 Report Card), if currently Grade 12',
    'form_137'           => 'Form 138 (Grade 12) or updated CTC of Form 137 with remark "For Evaluation Purposes Only", for SHS graduates',
]);

// -- Transferee-only docs ----------------------------------------
define('DOCS_TRANSFEREE', [
    'tor'                => 'TOR or Certificate of Grades — "For Evaluation Purposes Only"',
]);

// -- Foreign student docs (kept for system completeness) ---------
// Foreign applicants follow DOCS_CORE plus these extras.
define('DOCS_FOREIGN', [
    'tor'                => 'TOR or Certificate of Grades — "For Evaluation Purposes Only"',
    'passport'           => 'Passport',
    'visa_permit'        => 'Visa or Study Permit',
    'alien_cert'         => 'Alien Certificate of Registration',
]);

// -- Conditional slots: slot => doc_flags key on applicants.doc_flags ----
// A slot listed here is only required when its flag is true.
define('DOCS_CONDITIONAL', [
    'marriage_cert'          => 'married',
    'guardianship_affidavit' => 'guardian',
    'form_138'               => 'grade12',
    'form_137'               => 'shs_grad',
]);

// -- Official PLP courses offered --------------------------------
define('PLP_COURSES', [
    'BS Accountancy (BSA)',
    'BS Business Administration major in Marketing Management (BSBA)',
    'BS Entrepreneurship (BSENT)',
    'BS Hospitality Management (BSHM)',
    'Bachelor of Elementary Education (BEED)',
    'Bachelor of Secondary Education Major in English (BSED-ENG)',
    'Bachelor of Secondary Education Major in Filipino (BSED-FIL)',
    'Bachelor of Secondary Education Major in Mathematics (BSED-MATH)',
    'AB Psychology (AB Psych)',
    'BS Computer Science (BSCS)',
    'BS Information Technology (BSIT)',
    'BS Electronics Engineering (BSECE)',
    'BS Nursing (BSN)',
]);

// -- Departments / Colleges -------------------------------------
// Keep the canonical name in sync with `departments.name` (DB).
define('DEPT_CCS', 'College of Computer Studies');
define('DEPT_CON', 'College of Nursing');
define('DEPT_CBA', 'College of Business and Accountancy');
define('DEPT_COE', 'College of Education');
define('DEPT_CAS', 'College of Arts and Sciences');
define('DEPT_CEN', 'College of Engineering');

define('PLP_DEPARTMENTS', [
    DEPT_CCS,
    DEPT_CON,
    DEPT_CBA,
    DEPT_COE,
    DEPT_CAS,
    DEPT_CEN,
]);

// Course → department mapping.  This is the config-level fallback;
// the `course_departments` DB table is the source of truth once seeded.
define('COURSE_DEPARTMENT_MAP', [
    'BS Information Technology (BSIT)'                                  => DEPT_CCS,
    'BS Computer Science (BSCS)'                                        => DEPT_CCS,
    'BS Nursing (BSN)'                                                  => DEPT_CON,
    'BS Accountancy (BSA)'                                              => DEPT_CBA,
    'BS Business Administration major in Marketing Management (BSBA)'   => DEPT_CBA,
    'BS Entrepreneurship (BSENT)'                                       => DEPT_CBA,
    'BS Hospitality Management (BSHM)'                                  => DEPT_CBA,
    'Bachelor of Elementary Education (BEED)'                           => DEPT_COE,
    'Bachelor of Secondary Education Major in English (BSED-ENG)'       => DEPT_COE,
    'Bachelor of Secondary Education Major in Filipino (BSED-FIL)'      => DEPT_COE,
    'Bachelor of Secondary Education Major in Mathematics (BSED-MATH)'  => DEPT_COE,
    'AB Psychology (AB Psych)'                                          => DEPT_CAS,
    'BS Electronics Engineering (BSECE)'                                => DEPT_CEN,
]);

// -- Strand requirements per course (freshmen only) --------------
// Applicants should apply only to courses where their SHS strand is applicable.
define('COURSE_STRAND_MAP', [
    'BS Accountancy (BSA)'                                               => ['ABM'],
    'BS Business Administration major in Marketing Management (BSBA)'   => ['ABM'],
    'BS Entrepreneurship (BSENT)'                                        => ['ABM'],
    'BS Hospitality Management (BSHM)'                                   => ['ABM', 'TVL-HE'],
    'Bachelor of Elementary Education (BEED)'                            => ['HUMSS', 'GAS', 'TVL-Sports'],
    'Bachelor of Secondary Education Major in English (BSED-ENG)'       => ['HUMSS', 'GAS', 'STEM'],
    'Bachelor of Secondary Education Major in Filipino (BSED-FIL)'      => ['HUMSS', 'GAS', 'STEM'],
    'Bachelor of Secondary Education Major in Mathematics (BSED-MATH)'  => ['HUMSS', 'GAS', 'STEM'],
    'AB Psychology (AB Psych)'                                           => ['HUMSS', 'STEM'],
    'BS Computer Science (BSCS)'                                         => ['STEM'],
    'BS Information Technology (BSIT)'                                   => ['STEM', 'TVL-ICT'],
    'BS Electronics Engineering (BSECE)'                                 => ['STEM'],
    'BS Nursing (BSN)'                                                   => ['STEM'],
]);

// -- All SHS strands (for the registration dropdown) -------------
// Only strands accepted by at least one course in COURSE_STRAND_MAP are listed.
// TVL-IA, Arts Track, and Sports Track are valid DepEd strands but PLP currently
// has no courses that accept them — they have been removed to prevent applicants
// from hitting a registration dead-end. Add them back here and to COURSE_STRAND_MAP
// if PLP adds a qualifying course in a future school year.
define('SHS_STRANDS', [
    'ABM'        => 'ABM — Accountancy, Business and Management',
    'STEM'       => 'STEM — Science, Technology, Engineering and Mathematics',
    'HUMSS'      => 'HUMSS — Humanities and Social Sciences',
    'GAS'        => 'GAS — General Academic Strand',
    'TVL-HE'     => 'TVL — Home Economics',
    'TVL-ICT'    => 'TVL — Information and Communications Technology',
    'TVL-Sports' => 'TVL — Sports',
]);

// -- Document status labels -------------------------------------
define('DOC_STATUS_LABELS', [
    'pending'      => 'Pending',
    'uploaded'     => 'Uploaded',
    'under_review' => 'Under Review',
    'approved'     => 'Approved',
    'rejected'     => 'Declined',
]);

// -- Admission result labels ------------------------------------
// Waitlist tier was retired in the role redesign — the only outcomes
// are Accepted or Declined (a Professor's interview Fail blocks
// acceptance entirely). Legacy 'waitlisted' rows in the DB still
// render as "Waitlisted (legacy)" via the fallback in pages that
// read this constant. DB enum value stays 'rejected'; the label
// shown to users is "Declined" — softer wording requested by the
// admissions office.
define('RESULT_LABELS', [
    'accepted' => 'Accepted',
    'rejected' => 'Declined',
]);

// ----------------------------------------------------------------
// EXAM & INTERVIEW CAPACITY (from client interview)
// ----------------------------------------------------------------
define('EXAM_DEFAULT_DURATION',   90);   // 1 hr 30 min default (customizable)
define('EXAM_ROOM_CAPACITY',      35);   // max applicants per room
define('EXAM_DAILY_CAP',        3000);   // max applicants per day (all courses)

// ----------------------------------------------------------------
// PER-COURSE PASSING SCORE TIERS
// Source: client interview — BSIT confirmed; all others use same
// tier system pending client confirmation of exact passing marks.
//
// Ranking tiers (1–10 scale):
//   High    10, 9, 8, 7  → Passed
//   Average  6, 5, 4     → Passed
//   Low      3, 2, 1     → Rejected
// ----------------------------------------------------------------
define('SCORE_TIER_HIGH',    ['min' => 7, 'max' => 10, 'label' => 'High',    'verdict' => 'passed']);
define('SCORE_TIER_AVERAGE', ['min' => 4, 'max' => 6,  'label' => 'Average', 'verdict' => 'passed']);
define('SCORE_TIER_LOW',     ['min' => 1, 'max' => 3,  'label' => 'Low',     'verdict' => 'rejected']);

// Per-course passing configuration.
// 'pass_from' = minimum score to pass (scores >= pass_from → Passed).
// 'confirmed' = true if the client has confirmed the exact threshold.
// Default: pass_from=4 (Average tier and above pass) per BSIT-confirmed rule.
define('COURSE_PASSING_SCORES', [
    'BS Accountancy (BSA)'                                               => ['pass_from' => 4, 'confirmed' => false],
    'BS Business Administration major in Marketing Management (BSBA)'   => ['pass_from' => 4, 'confirmed' => false],
    'BS Entrepreneurship (BSENT)'                                        => ['pass_from' => 4, 'confirmed' => false],
    'BS Hospitality Management (BSHM)'                                   => ['pass_from' => 4, 'confirmed' => false],
    'Bachelor of Elementary Education (BEED)'                            => ['pass_from' => 4, 'confirmed' => false],
    'Bachelor of Secondary Education Major in English (BSED-ENG)'       => ['pass_from' => 4, 'confirmed' => false],
    'Bachelor of Secondary Education Major in Filipino (BSED-FIL)'      => ['pass_from' => 4, 'confirmed' => false],
    'Bachelor of Secondary Education Major in Mathematics (BSED-MATH)'  => ['pass_from' => 4, 'confirmed' => false],
    'AB Psychology (AB Psych)'                                           => ['pass_from' => 4, 'confirmed' => false],
    'BS Computer Science (BSCS)'                                         => ['pass_from' => 4, 'confirmed' => false],
    'BS Information Technology (BSIT)'                                   => ['pass_from' => 4, 'confirmed' => true],  // confirmed
    'BS Electronics Engineering (BSECE)'                                 => ['pass_from' => 4, 'confirmed' => false],
    'BS Nursing (BSN)'                                                   => ['pass_from' => 4, 'confirmed' => false],
]);

// -- Cloudflare Turnstile (captcha on login and register) -----------
define('TURNSTILE_SITE_KEY',   getenv('TURNSTILE_SITE_KEY')   ?: '');
define('TURNSTILE_SECRET_KEY', getenv('TURNSTILE_SECRET_KEY') ?: '');
// On only when both keys are set, so forms still work without keys.
define('CAPTCHA_ENABLED', TURNSTILE_SITE_KEY !== '' && TURNSTILE_SECRET_KEY !== '');

// -- Google sign in (students only) ---------------------------------
define('GOOGLE_CLIENT_ID',     getenv('GOOGLE_CLIENT_ID')     ?: '');
define('GOOGLE_CLIENT_SECRET', getenv('GOOGLE_CLIENT_SECRET') ?: '');
// On only when both are set, so the button hides without keys.
define('GOOGLE_ENABLED', GOOGLE_CLIENT_ID !== '' && GOOGLE_CLIENT_SECRET !== '');
// Must match an authorized redirect URI in Google Cloud exactly (local base URL includes /public).
// Order: GOOGLE_REDIRECT_URI env var, then (production) the host the visitor actually used,
// then BASE_URL. Using the real host keeps the redirect and the session cookie on the same site,
// so a wrong or missing APP_URL on Vercel no longer causes redirect_uri_mismatch.
define('GOOGLE_REDIRECT_URI', (function (): string {
    $override = trim((string) getenv('GOOGLE_REDIRECT_URI'));
    if ($override !== '') return $override;
    $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
    if (APP_ENV === 'production' && preg_match('/^[A-Za-z0-9.\-]+(:\d{1,5})?$/', $host)) {
        return 'https://' . $host . '/auth/google/callback';
    }
    return BASE_URL . '/auth/google/callback';
})());

// -- Email (Gmail SMTP via PHPMailer) -----------------------------
define('SMTP_HOST',       getenv('SMTP_HOST')       ?: 'smtp.gmail.com');
define('SMTP_PORT',       getenv('SMTP_PORT')       ?: 587);
define('SMTP_USER',       getenv('SMTP_USER')       ?: '');
define('SMTP_PASS',       getenv('SMTP_PASS')       ?: '');
define('SMTP_FROM_NAME',  getenv('SMTP_FROM_NAME')  ?: 'PLP Admissions');
define('SMTP_ENABLED',    !empty(SMTP_USER) && !empty(SMTP_PASS));

// -- Email verification ------------------------------------------
define('VERIFY_RESEND_COOLDOWN_SECS', 60);   // wait between resend requests
define('VERIFY_CODE_TTL_SECS',        15 * 60);  // 15-minute code lifetime
define('VERIFY_MAX_CODE_ATTEMPTS',    5);    // bad-code attempts per credential

// -- Progress steps (student tracker) ---------------------------
define('PROGRESS_STEPS', [
    'register'  => 'Register',
    'documents' => 'Submit Documents',
    'exam'      => 'Entrance Exam',
    'interview' => 'Interview',
    'result'    => 'Result',
]);

// -- Password reset (6-digit code) --------------------------------
define('RESET_CODE_TTL_SECS',  900);   // code lifetime: 15 min
define('RESET_RESEND_SECS',     60);   // rest between sends
define('RESET_MAX_ATTEMPTS',     5);   // wrong tries before the code dies
define('RESET_OK_TTL_SECS',    600);   // time to set a new password after confirming the code

// -- Remember me -------------------------------------------------
define('REMEMBER_COOKIE', 'plp_remember');
define('REMEMBER_DAYS',   30);
