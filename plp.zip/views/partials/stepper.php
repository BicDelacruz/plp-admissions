<?php
// ============================================================
// views/partials/stepper.php
// M7 — Applicant Progress Tracker
// Requires $stepperData array passed from the module:
//   ['current' => 'documents', 'steps' => [...]]
// ============================================================

$steps = [
    'documents' => 'Submit Documents',
    'exam'      => 'Entrance Exam',
    'interview' => 'Interview',
    'result'    => 'Result',
];

$currentStep = $stepperCurrent ?? 'documents';
// Treat 'register' as 'documents' since it's already done when the student is logged in
if ($currentStep === 'register') $currentStep = 'documents';

// Determine state for each step
$stepKeys = array_keys($steps);
$currentIndex = array_search($currentStep, $stepKeys);

function stepState(int $idx, int $currentIdx): string {
    if ($idx < $currentIdx)  return 'done';
    if ($idx === $currentIdx) return 'active';
    return 'locked';
}

// Step-to-URL map (students only)
// exam is intentionally null — once submitted it cannot be revisited
$stepUrls = [
    'documents' => url('/student/documents'),
    'exam'      => null,
    'interview' => url('/student/interview'),
    'result'    => url('/student/result'),
];
?>
<div class="stepper" aria-label="Admission progress">
    <?php foreach ($steps as $key => $label):
        $idx   = array_search($key, $stepKeys);
        $state = stepState($idx, $currentIndex);
        $href  = ($state === 'done' && $stepUrls[$key]) ? $stepUrls[$key] : null;
    ?>

        <?php if ($idx > 0): ?>
            <div class="step-connector <?= $state === 'done' || ($idx <= $currentIndex) ? 'done' : '' ?>"></div>
        <?php endif; ?>

        <div class="step <?= $state ?>" role="listitem" aria-label="<?= e($label) ?>: <?= $state ?>">
            <?php if ($href): ?>
                <a href="<?= $href ?>" class="step-dot" title="Go to <?= e($label) ?>">
            <?php else: ?>
                <div class="step-dot">
            <?php endif; ?>

                <?= $idx + 1 ?>

            <?php if ($href): ?></a><?php else: ?></div><?php endif; ?>

            <span class="step-label"><?= e($label) ?></span>
        </div>

    <?php endforeach; ?>
</div>