<?php
// ============================================================
// modules/exam/staff_slots.php
//
// Three-mode page for the exam-room scheduler. The whole page
// lives at /staff/exam/slots; mode is selected by query string:
//
//   (no params)            → College selector card grid (admin only;
//                            staff are redirected to their own college).
//   ?college=COLLEGE_NAME  → Card grid of exam-day slots for that
//                            college, with a "+ Add Slot" dashed
//                            card and the awaiting-applicants list
//                            scoped to the same college below.
//   ?slot=SLOT_ID          → Roster table for one slot (auto-paginated
//                            .auto-table with search + type filter, same
//                            as the audit log), with unassign + edit
//                            actions.
//
// Layout intentionally mirrors modules/interview/staff_setup.php
// so colleges, slots, and rosters all share the same family of
// card-grids and tables.
// ============================================================

require_once CORE_PATH . '/bootstrap.php';
Auth::requireRole(ROLE_PROCTOR, ROLE_SSO, ROLE_DEAN, ROLE_ADMIN);

$db          = db();
$staffId     = Auth::id();
$role        = Auth::role();
$isAdmin     = $role === ROLE_ADMIN;
$isSSO       = $role === ROLE_SSO;
$isProctor = $role === ROLE_PROCTOR;
// Admin and SSO can manage slots across all departments. Dean is
// read-only oversight. Proctor can only generate access codes for
// slots in their own department.
$canManage = $isAdmin || $isSSO;
$staffDept = $canManage ? '' : (string) user_department($staffId);
// Per-slot "can generate code" check. Admin and SSO can do it for
// any room. Proctors can do it only for slots in their own
// department.
$canGenerateCodeFor = function (string $slotDept) use ($isAdmin, $isSSO, $isProctor, $staffDept): bool {
    if ($isAdmin || $isSSO) return true;
    if ($isProctor && $slotDept !== '' && $slotDept === $staffDept) return true;
    return false;
};
$errors    = [];
$success   = [];

$schoolYear   = school_setting('current_school_year', date('Y') . '-' . (date('Y') + 1));
$activeExam   = $db->query('SELECT * FROM exams WHERE is_active=1 LIMIT 1')->fetch();

// ── One-time filled resync ────────────────────────────────────────
// Recalculate filled from actual applicant_exam_slots rows to fix
// any drift caused by manual DB edits, old bugs, or import scripts.
// This is cheap (one UPDATE) and idempotent — safe to run on every page load.
try {
    $db->exec(
        'UPDATE exam_slot_schedule ess
            SET filled = (
                SELECT COUNT(*) FROM applicant_exam_slots aes WHERE aes.slot_id = ess.id
            )'
    );
} catch (\Throwable $e) {
    // Non-fatal — log and continue
    error_log('filled resync failed: ' . $e->getMessage());
}
$activeExamId = $activeExam ? (int)$activeExam['id'] : null;

$examRoomCap  = (int) school_setting('exam_room_capacity', defined('EXAM_ROOM_CAPACITY') ? EXAM_ROOM_CAPACITY : 35);
$examDailyCap = (int) school_setting('exam_daily_cap',     defined('EXAM_DAILY_CAP')     ? EXAM_DAILY_CAP     : 3000);

// As of Chunk 7 the exam itself no longer has a scheduled start —
// scheduling lives on each slot. Default date for the Add/Batch
// modals is just "tomorrow".
$defaultDate = date('Y-m-d', strtotime('+1 day'));

// ----------------------------------------------------------------
// Routing — read URL params before POST handling so we redirect
// back to the right URL after every action.
// ----------------------------------------------------------------
$collegeParam = trim($_GET['college'] ?? '');
$slotIdParam  = (int)($_GET['slot']    ?? 0);

// Admin and SSO see the cross-college selector; Dean and Proctor
// land directly on their own college's slot grid (no point showing
// them a selector — they can only manage one college).
// $staffDept is computed above (needed for $canGenerateCodeFor).

// ----------------------------------------------------------------
// POST handlers — same as before, except every redirect now goes
// back to the appropriate ?college= page so the user lands on the
// view they were operating on.
// ----------------------------------------------------------------
function _slots_redirect_back(string $college = '', int $slotId = 0): void {
    if ($slotId > 0) {
        redirect('/staff/exam/slots?slot=' . $slotId);
    }
    if ($college !== '') {
        redirect('/staff/exam/slots?college=' . urlencode($college));
    }
    redirect('/staff/exam/slots');
}

// Shared ajax-or-flash-redirect responder. On AJAX requests, sends a
// JSON body and exits. Otherwise flashes a message and redirects back
// to the calling page. Used by every slot mutator below so the
// response pattern isn't retyped per action.
function _slots_respond(bool $ok, string $msg, string $college, int $slotId, array $extra = []): void {
    if (is_ajax_request()) {
        while (ob_get_level()) ob_end_clean();
        header('Content-Type: application/json');
        echo json_encode(array_merge(['ok' => $ok, 'error' => $ok ? null : $msg], $extra));
        exit;
    }
    Session::flash($ok ? 'success' : 'error', $msg);
    _slots_redirect_back($college, $slotId);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    // Most write actions redirect after success; pick the redirect target
    // up front based on the form's hidden context fields (with the URL
    // params as fallback).
    $ctxCollege = trim((string)($_POST['ctx_college'] ?? $collegeParam));
    $ctxSlotId  = (int)($_POST['ctx_slot'] ?? $slotIdParam);

    // ── Generate / extend per-room access code ───────────────
    //
    // Each room's proctor can independently issue an 8-character
    // code valid for EXAM_PASSWORD_EXPIRY_SECONDS (5 minutes). Admin
    // and SSO can do this for any room; Proctors only for slots
    // in their own department. Handled before the canManage gate so
    // Proctors are not redirected away.
    if ($action === 'generate_slot_code' || $action === 'extend_slot_code') {
        $slotId = (int)($_POST['slot_id'] ?? 0);
        $stmt   = $db->prepare(
            'SELECT id, department, room_label, access_password
               FROM exam_slot_schedule WHERE id = ? LIMIT 1'
        );
        $stmt->execute([$slotId]);
        $slotRow = $stmt->fetch();

        $isAjax = is_ajax_request();
        $respond = fn(bool $ok, string $msg = '', array $extra = []) =>
            _slots_respond($ok, $msg, $ctxCollege, $ctxSlotId, $extra);

        if (!$slotRow) {
            $respond(false, 'Slot not found.');
        }
        if (!$canGenerateCodeFor((string) $slotRow['department'])) {
            $respond(false, 'You can only generate codes for rooms in your own college.');
        }

        if ($action === 'extend_slot_code') {
            if (empty($slotRow['access_password'])) {
                $respond(false, 'No code set yet — generate one first.');
            }
            $db->prepare('UPDATE exam_slot_schedule SET password_issued_at = NOW() WHERE id = ?')
               ->execute([$slotId]);
            audit_log('exam_slot_code_extended',
                "Extended access code timer for slot {$slotId} ({$slotRow['room_label']})");
            $respond(true, 'Code timer reset.', [
                'password'   => $slotRow['access_password'],
                'expires_in' => EXAM_PASSWORD_EXPIRY_SECONDS,
            ]);
        } else {
            $newPwd = generate_exam_password();
            $db->prepare(
                'UPDATE exam_slot_schedule
                    SET access_password = ?, password_issued_at = NOW()
                  WHERE id = ?'
            )->execute([$newPwd, $slotId]);
            audit_log('exam_slot_code_generated',
                "Generated access code for slot {$slotId} ({$slotRow['room_label']})");
            $respond(true, 'New code issued.', [
                'password'   => $newPwd,
                'expires_in' => EXAM_PASSWORD_EXPIRY_SECONDS,
            ]);
        }
    }

    // ── Inline edit of a slot's room label ──────────────────
    // (Admin/SSO only — same as the rest of the slot mutators.)
    if ($action === 'update_room_label') {
        if (!$canManage) {
            _slots_respond(false, 'Read-only access — only SSO and Admin can rename rooms.', $ctxCollege, $ctxSlotId);
        }
        $slotId  = (int)($_POST['slot_id']    ?? 0);
        $newRoom = trim((string)($_POST['room_label'] ?? ''));
        if (!$slotId || $newRoom === '') {
            if (is_ajax_request()) {
                _slots_respond(false, 'Room label cannot be empty.', $ctxCollege, $ctxSlotId);
            }
            $errors[] = 'Room label cannot be empty.';
        } else {
            $db->prepare('UPDATE exam_slot_schedule SET room_label = ? WHERE id = ?')
               ->execute([$newRoom, $slotId]);
            audit_log('exam_slot_room_renamed', "Slot {$slotId} room label → {$newRoom}");
            _slots_respond(true, 'Room label updated.', $ctxCollege, $ctxSlotId, ['room_label' => $newRoom]);
        }
    }

    // Only Admin and SSO can mutate exam slots from this point on.
    // Dean and Proctor reach this page in read-only mode — if any
    // other action posts through, reject it.
    if (!$canManage) {
        Session::flash('error', 'Read-only — only SSO and Admin can modify exam slots.');
        _slots_redirect_back($ctxCollege, $ctxSlotId);
    }

    // ── Update exam config (room default + daily cap) ────────────
    if ($action === 'update_exam_config') {
        $upsert = 'INSERT INTO school_settings (setting_key, setting_value) VALUES (?,?)
                   ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value';
        $roomCap  = max(1, (int)($_POST['exam_room_capacity'] ?? 35));
        $dailyCap = max(1, (int)($_POST['exam_daily_cap']     ?? 3000));
        $db->prepare($upsert)->execute(['exam_room_capacity', $roomCap]);
        $db->prepare($upsert)->execute(['exam_daily_cap',     $dailyCap]);
        audit_log('exam_config_updated', "Room cap={$roomCap}, Daily cap={$dailyCap}");
        Session::flash('success', 'Exam config saved.');
        _slots_redirect_back($ctxCollege, $ctxSlotId);
    }

    // ── Add a new exam slot ──────────────────────────────────────
    if ($action === 'add_slot') {
        $date     = trim($_POST['exam_date']  ?? '');
        $time     = trim($_POST['slot_time']  ?? '08:00');
        $endTime  = trim($_POST['end_time']   ?? '');
        $room     = trim($_POST['room_label'] ?? '');
        $capacity = (int)($_POST['capacity']  ?? 35);
        $slotDept = $canManage
            ? trim($_POST['department'] ?? '')
            : user_department($staffId);

        // Default close time = opens + 90 minutes if the form didn't
        // supply one (older form variants, JS off, etc).
        if ($endTime === '') {
            $endTime = date('H:i', strtotime($time . ' +90 minutes'));
        }

        if (!$date)              $errors[] = 'Exam date is required.';
        if (!$room)              $errors[] = 'Room label is required.';
        if (!$slotDept)          $errors[] = 'College / Department is required.';
        if ($capacity < 1)       $errors[] = 'Capacity must be at least 1.';
        if ($capacity > 500)     $errors[] = 'Capacity above 500 is unrealistic.';
        if (strtotime($endTime) <= strtotime($time)) {
            $errors[] = 'Close time must be after the start time.';
        }

        if (!$errors) {
            $db->prepare(
                'INSERT INTO exam_slot_schedule
                    (exam_id, exam_date, slot_time, end_time, room_label, department, capacity, school_year, created_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
            )->execute([$activeExamId, $date, $time . ':00', $endTime . ':00', $room, $slotDept, $capacity, $schoolYear, $staffId]);
            audit_log('exam_slot_added',
                "Added slot: {$date} {$time}-{$endTime} {$room} [{$slotDept}] (cap {$capacity})");

            // Backfill: any applicant who advanced to exam stage
            // before this slot existed should now get auto-assigned.
            // Without this, those students stay on the "Awaiting Slot
            // Assignment" page until someone manually intervenes.
            $assigned = 0;
            if (function_exists('backfill_exam_slot_assignments')) {
                $assigned = backfill_exam_slot_assignments();
            }

            Session::flash(
                'success',
                "Slot added: {$room} ({$slotDept}) on " . date('M j, Y', strtotime($date)) . " at {$time}-{$endTime}."
                . ($assigned > 0 ? " Auto-assigned {$assigned} waiting applicant(s)." : '')
            );
            _slots_redirect_back($slotDept ?: $ctxCollege);
        }
    }

    // ── Edit an existing slot ───────────────────────────────────
    if ($action === 'edit_slot') {
        $slotId   = (int)($_POST['slot_id']   ?? 0);
        $date     = trim($_POST['exam_date']  ?? '');
        $time     = trim($_POST['slot_time']  ?? '08:00');
        $endTime  = trim($_POST['end_time']   ?? '');
        $room     = trim($_POST['room_label'] ?? '');
        $capacity = (int)($_POST['capacity']  ?? 35);
        $slotDept = $canManage
            ? trim($_POST['department'] ?? '')
            : user_department($staffId);

        // Default close time = opens + 90 minutes if the form didn't
        // supply one (older form variants, JS off, etc).
        if ($endTime === '') {
            $endTime = date('H:i', strtotime($time . ' +90 minutes'));
        }

        if (!$slotId)          $errors[] = 'Invalid slot.';
        if (!$date)            $errors[] = 'Exam date is required.';
        if (!$room)            $errors[] = 'Room label is required.';
        if (!$slotDept)        $errors[] = 'College / Department is required.';
        if ($capacity < 1)     $errors[] = 'Capacity must be at least 1.';
        if ($capacity > 500)   $errors[] = 'Capacity above 500 is unrealistic.';
        if (strtotime($endTime) <= strtotime($time)) {
            $errors[] = 'Close time must be after the start time.';
        }

        if (!$errors) {
            $stmt = $db->prepare('SELECT COUNT(*) FROM applicant_exam_slots WHERE slot_id=?');
            $stmt->execute([$slotId]);
            $filled = (int)$stmt->fetchColumn();
            if ($capacity < $filled) {
                $errors[] = "Cannot shrink capacity below {$filled} (currently filled).";
            } else {
                $db->prepare(
                    'UPDATE exam_slot_schedule
                        SET exam_date=?, slot_time=?, end_time=?, room_label=?, department=?, capacity=?
                      WHERE id=?'
                )->execute([$date, $time . ':00', $endTime . ':00', $room, $slotDept, $capacity, $slotId]);
                audit_log('exam_slot_edited',
                    "Edited slot {$slotId}: {$date} {$time}-{$endTime} {$room} [{$slotDept}] (cap {$capacity})");
                Session::flash('success', 'Slot updated.');
                // If we were on the roster page, stay on it; otherwise return to the college grid.
                if ($ctxSlotId > 0) {
                    _slots_redirect_back('', $ctxSlotId);
                }
                _slots_redirect_back($slotDept);
            }
        }
    }

    // ── Edit slot capacity inline ───────────────────────────────
    if ($action === 'edit_capacity') {
        $slotId = (int)($_POST['slot_id'] ?? 0);
        $cap    = max(1, (int)($_POST['capacity'] ?? 35));
        if ($slotId) {
            $stmt = $db->prepare(
                'SELECT (SELECT COUNT(*) FROM applicant_exam_slots WHERE slot_id=?) AS filled'
            );
            $stmt->execute([$slotId]);
            $filled = (int)$stmt->fetchColumn();
            if ($cap < $filled) {
                $errors[] = "Cannot shrink capacity below {$filled} (currently filled).";
            } else {
                $db->prepare('UPDATE exam_slot_schedule SET capacity=? WHERE id=?')
                   ->execute([$cap, $slotId]);
                audit_log('exam_slot_capacity_changed', "Slot {$slotId} capacity → {$cap}");
                Session::flash('success', 'Capacity updated.');
                _slots_redirect_back($ctxCollege, $ctxSlotId);
            }
        }
    }

    // ── Delete a slot (only if empty) ───────────────────────────
    if ($action === 'delete_slot') {
        $slotId = (int)($_POST['slot_id'] ?? 0);
        if ($slotId) {
            $stmt = $db->prepare('SELECT COUNT(*) FROM applicant_exam_slots WHERE slot_id=?');
            $stmt->execute([$slotId]);
            if ((int)$stmt->fetchColumn() > 0) {
                $errors[] = 'Cannot delete a slot that has applicants assigned. Unassign them first.';
            } else {
                $db->prepare('DELETE FROM exam_slot_schedule WHERE id=?')->execute([$slotId]);
                audit_log('exam_slot_deleted', "Deleted slot {$slotId}");
                Session::flash('success', 'Slot deleted.');
                _slots_redirect_back($ctxCollege);
            }
        }
    }

    // ── Bulk delete slots (from select-mode bar) ────────────────
    if ($action === 'delete_slots_bulk') {
        $rawIds = trim($_POST['ids'] ?? '');
        $ids    = array_values(array_filter(array_map('intval', explode(',', $rawIds)), fn($v) => $v > 0));
        if (empty($ids)) {
            Session::flash('error', 'No slots selected.');
            _slots_redirect_back($ctxCollege);
        }

        $ph     = implode(',', array_fill(0, count($ids), '?'));
        // Skip slots that have at least one applicant assigned — same rule
        // the single-row delete enforces. Only the empty ones are removed.
        $bkStmt = $db->prepare(
            "SELECT s.id, COUNT(aes.id) AS filled
               FROM exam_slot_schedule s
               LEFT JOIN applicant_exam_slots aes ON aes.slot_id = s.id
              WHERE s.id IN ({$ph})
              GROUP BY s.id"
        );
        $bkStmt->execute($ids);
        $deletable = [];
        $skipped   = 0;
        foreach ($bkStmt->fetchAll() as $row) {
            if ((int)$row['filled'] > 0) { $skipped++; continue; }
            $deletable[] = (int)$row['id'];
        }

        $deletedCount = 0;
        if (!empty($deletable)) {
            $delPh = implode(',', array_fill(0, count($deletable), '?'));
            $del   = $db->prepare("DELETE FROM exam_slot_schedule WHERE id IN ({$delPh})");
            $del->execute($deletable);
            $deletedCount = $del->rowCount();
            audit_log('exam_slots_bulk_deleted',
                "Bulk-deleted {$deletedCount} slot(s): " . implode(',', $deletable));
        }

        if ($deletedCount > 0 && $skipped > 0) {
            Session::flash('success', "{$deletedCount} slot(s) removed; {$skipped} skipped (have applicants).");
        } elseif ($deletedCount > 0) {
            Session::flash('success', "{$deletedCount} slot(s) removed.");
        } elseif ($skipped > 0) {
            Session::flash('error', "Nothing removed — all {$skipped} selected slot(s) have applicants.");
        }
        _slots_redirect_back($ctxCollege);
    }

    // ── Assign applicant to slot ────────────────────────────────
    if ($action === 'assign') {
        $applicantId = (int)($_POST['applicant_id'] ?? 0);
        $slotId      = (int)($_POST['slot_id']      ?? 0);
        if (!$applicantId || !$slotId) {
            $errors[] = 'Applicant and slot are both required.';
        } else {
            $stmt = $db->prepare(
                'SELECT s.capacity, s.exam_date, s.department,
                        (SELECT COUNT(*) FROM applicant_exam_slots WHERE slot_id=s.id) AS filled
                   FROM exam_slot_schedule s WHERE s.id=?'
            );
            $stmt->execute([$slotId]);
            $slot = $stmt->fetch();
            if (!$slot) {
                $errors[] = 'Slot not found.';
            } elseif ((int)$slot['filled'] >= (int)$slot['capacity']) {
                $errors[] = 'Slot is full.';
            } else {
                $dailyCap = (int) school_setting('exam_daily_cap', defined('EXAM_DAILY_CAP') ? EXAM_DAILY_CAP : 3000);
                $stmt2 = $db->prepare(
                    'SELECT COUNT(*) FROM applicant_exam_slots aes
                       JOIN exam_slot_schedule s ON s.id = aes.slot_id
                      WHERE s.exam_date = ? AND s.school_year = ?'
                );
                $stmt2->execute([$slot['exam_date'], $schoolYear]);
                $dayCount = (int)$stmt2->fetchColumn();
                if ($dayCount >= $dailyCap) {
                    $errors[] = "Daily exam cap of {$dailyCap} reached for "
                              . date('M j, Y', strtotime($slot['exam_date']))
                              . ". Add more slots on another day or increase the daily cap in Exam Config.";
                } else {
                    $stmt = $db->prepare(
                        'SELECT a.overall_status, a.course_applied, u.department
                           FROM applicants a
                           JOIN users u ON u.id = a.user_id
                          WHERE a.id = ?'
                    );
                    $stmt->execute([$applicantId]);
                    $applRow = $stmt->fetch();
                    if (!$applRow) {
                        $errors[] = 'Applicant not found.';
                    } elseif ($applRow['overall_status'] !== 'exam') {
                        $errors[] = "Applicant is not at exam stage (currently: {$applRow['overall_status']}).";
                    } else {
                        // Cross-college guard. An applicant must only land in
                        // a slot for their own college, regardless of how
                        // they got here (manual assign, auto-assign,
                        // reschedule). If the slot's department doesn't
                        // match, refuse with a clear message rather than
                        // booking them into a foreign room.
                        $applDept = trim((string)($applRow['department'] ?? ''))
                                 ?: course_to_department((string)$applRow['course_applied']);
                        $slotDept = trim((string)($slot['department'] ?? ''));
                        if ($applDept !== '' && $slotDept !== '' && strtolower(trim($applDept)) !== strtolower(trim($slotDept))) {
                            $errors[] = "This slot is for {$slotDept}, but the applicant is in {$applDept}. "
                                      . "Create a slot for {$applDept} instead.";
                        } else {
                            $db->prepare(
                                'INSERT INTO applicant_exam_slots (applicant_id, slot_id, assigned_at)
                                 VALUES (?, ?, NOW())
                                 ON CONFLICT (applicant_id) DO UPDATE SET slot_id=EXCLUDED.slot_id, assigned_at=NOW()'
                            )->execute([$applicantId, $slotId]);
                            // Keep filled in sync so auto-assign queries stay accurate
                            $db->prepare('UPDATE exam_slot_schedule SET filled = filled + 1 WHERE id = ?')
                               ->execute([$slotId]);
                            audit_log('exam_slot_assigned',
                                "Assigned applicant {$applicantId} → slot {$slotId}",
                                'applicant', $applicantId);
                            Session::flash('success', 'Applicant assigned.');
                            _slots_redirect_back($slot['department'] ?: $ctxCollege, $ctxSlotId);
                        }
                    }
                }
            }
        }
    }

    // ── B3: Batch create exam slots ────────────────────────────
    if ($action === 'batch_create_slots') {
        $bStartDate = trim($_POST['batch_start_date'] ?? '');
        $bEndDate   = trim($_POST['batch_end_date']   ?? '');
        $bTime      = trim($_POST['batch_time']       ?? '08:00');
        $bEndTime   = trim($_POST['batch_end_time']   ?? '');
        $bRooms     = $_POST['batch_rooms'] ?? [];
        if (!is_array($bRooms)) $bRooms = [$bRooms];
        $bRooms     = array_filter(array_map('trim', $bRooms));
        $bCapacity  = max(1, (int)($_POST['batch_capacity'] ?? $examRoomCap ?? 35));
        $bDept      = $canManage ? trim($_POST['batch_department'] ?? '') : user_department($staffId);
        $bDays      = array_map('intval', $_POST['batch_days'] ?? [1,2,3,4,5]);

        if ($bEndTime === '') {
            $bEndTime = date('H:i', strtotime($bTime . ' +90 minutes'));
        }

        if (!$bStartDate || !$bEndDate) $errors[] = 'Start and end dates are required.';
        elseif ($bEndDate < $bStartDate) $errors[] = 'End date must be after start date.';
        elseif (empty($bRooms)) $errors[] = 'At least one room label is required.';
        elseif (!$bDept) $errors[] = 'Department is required.';
        elseif (strtotime($bEndTime) <= strtotime($bTime)) $errors[] = 'Close time must be after the start time.';
        else {
            $totalCreated = 0;
            foreach ($bRooms as $bRoom) {
                $created = batch_create_exam_slots([
                    'start_date' => $bStartDate,
                    'end_date'   => $bEndDate,
                    'slot_time'  => $bTime,
                    'end_time'   => $bEndTime,
                    'room_label' => $bRoom,
                    'capacity'   => $bCapacity,
                    'days'       => $bDays,
                ], $bDept, $staffId);
                $totalCreated += $created;
            }
            Session::flash('success', "Created {$totalCreated} exam slot(s) in batch across " . count($bRooms) . " room(s).");
            _slots_redirect_back($bDept);
        }
    }

    // ── Unassign applicant from their slot ──────────────────────
    if ($action === 'unassign') {
        $applicantId = (int)($_POST['applicant_id'] ?? 0);
        if ($applicantId) {
            // Get the slot_id before deleting so we can decrement filled
            $slotLookup = $db->prepare('SELECT slot_id FROM applicant_exam_slots WHERE applicant_id = ? LIMIT 1');
            $slotLookup->execute([$applicantId]);
            $unassignSlotId = $slotLookup->fetchColumn();

            $db->prepare('DELETE FROM applicant_exam_slots WHERE applicant_id=?')
               ->execute([$applicantId]);

            // Keep filled in sync so auto-assign can find this freed seat
            if ($unassignSlotId) {
                $db->prepare('UPDATE exam_slot_schedule SET filled = GREATEST(filled - 1, 0) WHERE id = ?')
                   ->execute([$unassignSlotId]);
            }

            audit_log('exam_slot_unassigned', "Unassigned applicant {$applicantId} from their slot",
                'applicant', $applicantId);
            Session::flash('success', 'Applicant unassigned.');
            _slots_redirect_back($ctxCollege, $ctxSlotId);
        }
    }
}

// ----------------------------------------------------------------
// Routing — pick which view to render.
// ----------------------------------------------------------------
$mode = 'colleges';
if ($slotIdParam > 0)              $mode = 'roster';
elseif ($collegeParam !== '')      $mode = 'slots';
elseif (!$canManage && $staffDept) { $collegeParam = $staffDept; $mode = 'slots'; }

// ----------------------------------------------------------------
// Mode-specific data loading.
// ----------------------------------------------------------------
$departments = departments_list();

$slotsForCollege = [];
$rosterBySlot    = [];
$slotDetail      = null;
$slotRoster      = [];

if ($mode === 'slots') {
    // College must be valid (or scoped user's own)
    if (!$canManage && $collegeParam !== $staffDept) {
        $collegeParam = $staffDept;
    }

    // Slots in this college for the active school year. The
    // pw_secs_left is computed in the database so PHP / DB timezone
    // differences can't skew the countdown.
    $stmt = $db->prepare(
        "SELECT s.id, s.exam_date, s.slot_time, s.end_time,
                s.room_label, s.department, s.capacity,
                s.access_password, s.password_issued_at,
                GREATEST(
                    0,
                    " . (int) EXAM_PASSWORD_EXPIRY_SECONDS . "
                        - TRUNC(EXTRACT(EPOCH FROM (NOW() - COALESCE(s.password_issued_at, TIMESTAMP '1970-01-01 00:00:00'))))
                ) AS pw_secs_left,
                (SELECT COUNT(*) FROM applicant_exam_slots WHERE slot_id = s.id) AS filled
           FROM exam_slot_schedule s
          WHERE s.school_year = ?
            AND s.department  = ?
          ORDER BY s.exam_date ASC, s.slot_time ASC, s.room_label ASC"
    );
    $stmt->execute([$schoolYear, $collegeParam]);
    $slotsForCollege = $stmt->fetchAll();

}

if ($mode === 'roster') {
    $stmt = $db->prepare(
        "SELECT s.*,
                GREATEST(
                    0,
                    " . (int) EXAM_PASSWORD_EXPIRY_SECONDS . "
                        - TRUNC(EXTRACT(EPOCH FROM (NOW() - COALESCE(s.password_issued_at, TIMESTAMP '1970-01-01 00:00:00'))))
                ) AS pw_secs_left,
                (SELECT COUNT(*) FROM applicant_exam_slots WHERE slot_id = s.id) AS filled
           FROM exam_slot_schedule s
          WHERE s.id = ?
          LIMIT 1"
    );
    $stmt->execute([$slotIdParam]);
    $slotDetail = $stmt->fetch();

    if (!$slotDetail) {
        Session::flash('error', 'Slot not found.');
        redirect('/staff/exam/slots');
    }

    // Staff can only see slots in their own college (unless they can
    // manage across colleges — admin or SSO).
    if (!$canManage && $slotDetail['department'] !== $staffDept) {
        Session::flash('error', 'You can only view slots in your own college.');
        redirect('/staff/exam/slots');
    }

    // ── Auto-issue access code at the slot's start time ──────────
    //
    // The proctor for this room shouldn't have to click "Generate" —
    // the moment the slot's scheduled start time arrives (and the slot
    // hasn't already ended) the system issues a fresh code and starts
    // the 5-minute window. Manual control is preserved through the
    // New / Extend buttons rendered below.
    //
    // Window: slot_opens ≤ now ≤ slot_closes. Earlier than slot_opens
    // and the panel sits at "No active code" so a proctor previewing
    // the page during the morning doesn't burn a code at midnight.
    $slotOpensTs      = strtotime($slotDetail['exam_date'] . ' ' . $slotDetail['slot_time']);
    $slotClosesTs     = !empty($slotDetail['end_time'])
        ? strtotime($slotDetail['exam_date'] . ' ' . $slotDetail['end_time'])
        : ($slotOpensTs + 5400); // legacy fallback: 90-minute window
    if ($slotClosesTs <= $slotOpensTs) $slotClosesTs += 86400; // wrap past midnight
    $nowTs            = time();
    $slotIsLive       = ($nowTs >= $slotOpensTs && $nowTs <= $slotClosesTs);

    $hasValidCode     = !empty($slotDetail['access_password'])
                          && (int)($slotDetail['pw_secs_left'] ?? 0) > 0;
    $canIssueForRoom  = $canGenerateCodeFor((string) $slotDetail['department']);

    if ($slotIsLive && $canIssueForRoom && !$hasValidCode) {
        $autoPwd = generate_exam_password();
        $db->prepare(
            'UPDATE exam_slot_schedule
                SET access_password = ?, password_issued_at = NOW()
              WHERE id = ?'
        )->execute([$autoPwd, (int) $slotDetail['id']]);
        audit_log('exam_slot_code_auto_generated',
            "Auto-issued access code for slot {$slotDetail['id']} ({$slotDetail['room_label']})");

        // Reflect the freshly-issued code in the in-memory row so the
        // panel below renders with a full 5-minute countdown immediately.
        $slotDetail['access_password']    = $autoPwd;
        $slotDetail['password_issued_at'] = date('Y-m-d H:i:s');
        $slotDetail['pw_secs_left']       = EXAM_PASSWORD_EXPIRY_SECONDS;
    }

    // Roster table — search + applicant-type filter, paginated in SQL.
    // Same auto-fit scheme as the audit log: AutoPageSize (app.js) measures how
    // many fixed-height rows fit and reloads with ?per_page=; see
    // auto_per_page() in helpers.php.
    $rosterSearch = trim($_GET['q'] ?? '');
    $rosterType   = trim($_GET['type'] ?? '');
    if (!in_array($rosterType, ['freshman', 'transferee', 'foreign'], true)) {
        $rosterType = '';
    }
    $rosterPerPage = auto_per_page('exam-slot-roster');

    $rWhere  = ['aes.slot_id = :slot_id'];
    $rParams = [':slot_id' => $slotIdParam];
    if ($rosterSearch !== '') {
        // Distinct placeholder per column (emulated prepares + the pooler).
        $rCols  = ['u.name', 'u.first_name', 'u.last_name', 'u.email', 'a.course_applied'];
        $rLikes = [];
        foreach ($rCols as $i => $col) {
            $rLikes[]            = "{$col} ILIKE :q{$i}";
            $rParams[":q{$i}"]   = '%' . $rosterSearch . '%';
        }
        $rWhere[] = '(' . implode(' OR ', $rLikes) . ')';
    }
    if ($rosterType !== '') {
        $rWhere[]            = 'a.applicant_type = :atype';
        $rParams[':atype']   = $rosterType;
    }
    $rWhereStr = implode(' AND ', $rWhere);
    $rFrom     = 'FROM applicant_exam_slots aes
                  JOIN applicants a ON a.id = aes.applicant_id
                  JOIN users u      ON u.id = a.user_id';

    $rosterResult = paginate(
        $db,
        "SELECT COUNT(*) {$rFrom} WHERE {$rWhereStr}",
        "SELECT aes.applicant_id, aes.assigned_at,
                u.name AS student_name, a.course_applied, a.applicant_type,
                u.email AS student_email,
                u.first_name, u.middle_name, u.last_name, u.suffix
           {$rFrom}
          WHERE {$rWhereStr}
          ORDER BY u.last_name ASC, u.first_name ASC, u.name ASC, aes.applicant_id ASC",
        $rParams, max(1, (int)($_GET['page'] ?? 1)), $rosterPerPage
    );
    $slotRoster = $rosterResult['data'];
}

if ($mode === 'colleges') {
    // Per-college counts for the card grid.
    $collegeCounts = [];
    foreach ($departments as $dept) {
        $stmt = $db->prepare(
            "SELECT
                 COUNT(*)                                     AS total_slots,
                 SUM(CASE WHEN s.exam_date >= CURRENT_DATE THEN 1 ELSE 0 END) AS upcoming_slots,
                 COALESCE(SUM(s.capacity), 0)                 AS total_seats,
                 COALESCE(SUM(
                     (SELECT COUNT(*) FROM applicant_exam_slots
                       WHERE slot_id = s.id)
                 ), 0)                                        AS filled_seats
               FROM exam_slot_schedule s
              WHERE s.department = ?
                AND s.school_year = ?"
        );
        $stmt->execute([$dept, $schoolYear]);
        $row = $stmt->fetch() ?: [];
        $collegeCounts[$dept] = [
            'total_slots'    => (int)($row['total_slots']    ?? 0),
            'upcoming_slots' => (int)($row['upcoming_slots'] ?? 0),
            'total_seats'    => (int)($row['total_seats']    ?? 0),
            'filled_seats'   => (int)($row['filled_seats']   ?? 0),
        ];
    }
}

ob_start();
?>

<style>
/* Generic flash-message colors handled by the layout. */

/* Card base, grid and hover come from the shared selector-card rules in app.css. */

/* Active access-code badge on a slot card */
.es-card-code-badge {
    background: var(--success-muted, #e6f4ec);
    color: var(--success, #2d6a4f);
    font-family: monospace;
    font-weight: var(--weight-semibold);
    letter-spacing: .08em;
}
.es-card-code-badge.is-warn { background: #fef3c7; color: #92400e; }

/* Roster code panel (proctor-facing) */
.es-code-panel {
    display: flex; align-items: center; gap: var(--space-3);
    padding: var(--space-3) var(--space-4);
    background: var(--bg-elevated);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    margin-bottom: var(--space-4);
    flex-wrap: wrap;
}
.es-code-panel-label {
    display: inline-flex; align-items: center; gap: 6px;
    font-size: var(--text-sm); color: var(--text-secondary);
    flex-shrink: 0;
}
.es-code-display {
    font-family: monospace;
    font-size: var(--text-lg);
    font-weight: var(--weight-semibold);
    letter-spacing: .15em;
    padding: 4px 12px;
    background: var(--bg-subtle);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    color: var(--text-primary);
}
.es-code-display.is-empty {
    color: var(--text-tertiary);
    font-weight: normal;
    letter-spacing: normal;
}
.es-code-timer {
    font-size: var(--text-sm);
    font-weight: var(--weight-medium);
    color: var(--success, #2d6a4f);
}
.es-code-timer.is-warn   { color: #d97706; }
.es-code-timer.is-expired { color: var(--error); }

.es-card-edit-btn {
    position: absolute; top: var(--space-3); right: var(--space-3);
    width: 28px; height: 28px;
    display: flex; align-items: center; justify-content: center;
    border-radius: var(--radius);
    background: var(--bg-subtle); color: var(--text-secondary);
    border: 1px solid transparent;
    cursor: pointer;
}
.es-card-edit-btn:hover { border-color: var(--border); color: var(--accent); }

/* ── Bulk-select mode for slot cards ────────────────────────── */
/* Hide the per-card edit pencil while selecting so the click is unambiguous. */
.es-slot-grid.is-selecting .es-card-edit-btn { display:none !important; }

/* Roster page — the table is an .auto-table-wrap (app.css) that fills the page
   height left under these rows; keep the rows above it from shrinking. */
.es-code-panel { flex-shrink: 0; }
</style>

<?php if (!empty($errors)): ?>
    <?php foreach ($errors as $err): ?>
        <div class="alert alert-error" style="margin-bottom:var(--space-3)"><?= e($err) ?></div>
    <?php endforeach; ?>
<?php endif; ?>
<?php foreach ($success as $s): ?>
    <div class="alert alert-success" style="margin-bottom:var(--space-3)"><?= e($s) ?></div>
<?php endforeach; ?>

<?php if ($mode === 'colleges'): ?>

    <!-- ============================================================
         MODE 1 — COLLEGE SELECTOR
         (Admins land here. Staff are auto-routed to their college.)
    ============================================================ -->
    <?php if (empty($departments)): ?>
        <div class="select-empty">No colleges / departments configured in the system.</div>
    <?php else: ?>
        <div class="select-grid college-grid">
            <?php foreach ($departments as $dept):
                $info = $collegeCounts[$dept] ?? [
                    'total_slots' => 0, 'upcoming_slots' => 0,
                    'total_seats' => 0, 'filled_seats' => 0,
                ];
                $deptNeedsSetup = ((int)$info['upcoming_slots']) === 0;
            ?>
                <a href="<?= e(url('/staff/exam/slots') . '?college=' . urlencode($dept)) ?>" class="select-card college-card">
                    <?php if ($deptNeedsSetup): ?>
                        <span class="select-card-dot" title="No upcoming slots — needs setup"></span>
                    <?php endif; ?>
                    <div class="select-card-title"><?= e($dept) ?></div>
                    <div class="select-card-meta">
                        <div class="select-card-meta-row">
                            <?= (int)$info['upcoming_slots'] ?> upcoming slot<?= (int)$info['upcoming_slots'] === 1 ? '' : 's' ?>
                        </div>
                        <div class="select-card-meta-row">
                            <?= (int)$info['filled_seats'] ?> / <?= (int)$info['total_seats'] ?> seats filled
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

<?php elseif ($mode === 'slots'): ?>

    <!-- ============================================================
         MODE 2 — SLOT CARD GRID FOR ONE COLLEGE
    ============================================================ -->
    <div data-page-actions>
    <?php if ($canManage && !empty($slotsForCollege)): ?>
        <?= ui_button('Select', ['variant' => 'ghost', 'attrs' => ['id' => 'es-select-toggle', 'onclick' => 'toggleEsSelectMode()']]) ?>
    <?php endif; ?>
    <?php if ($canManage): ?>
        <?= ui_button('Export Lists', ['href' => url('/staff/exam/export-rooms'), 'icon' => 'ic_fluent_document_24_regular', 'attrs' => ['target' => '_blank', 'rel' => 'noopener', 'title' => 'Printable per-room sheets to post on the school board']]) ?>
        <?= ui_button('Config', ['variant' => 'ghost', 'icon' => 'ic_fluent_settings_24_regular', 'attrs' => ['onclick' => "document.getElementById('exam-config-modal').style.display='flex'"]]) ?>
    <?php else: ?>
        <span class="badge badge-neutral">
            <?= icon('ic_fluent_eye_24_regular', 12) ?> Read-only
        </span>
    <?php endif; ?>
    </div>

    <?php
    $today      = date('Y-m-d');
    $totalCap   = array_sum(array_column($slotsForCollege, 'capacity'));
    $totalFil   = array_sum(array_column($slotsForCollege, 'filled'));

    // Build a date map for the toolbar filter dropdown. One entry per
    // distinct exam date, with a count of slots on that date and a
    // "past" flag for dates earlier than today. Filtering is pure
    // client-side via data-date on each card — no extra DB queries.
    $slotDateMap = [];
    foreach ($slotsForCollege as $_s) {
        $d = (string)($_s['exam_date'] ?? '');
        if ($d === '') continue;
        if (!isset($slotDateMap[$d])) {
            $slotDateMap[$d] = ['date' => $d, 'count' => 0, 'is_past' => $d < $today];
        }
        $slotDateMap[$d]['count']++;
    }
    usort($slotDateMap, fn($a, $b) => $a['date'] <=> $b['date']);
    ?>
    <div class="select-toolbar">
        <?php if (count($slotDateMap) > 1): ?>
            <select id="es-date-filter" class="form-control" title="Filter by exam date">
                <option value="" data-count="<?= count($slotsForCollege) ?>">
                    All dates · <?= count($slotsForCollege) ?> slot<?= count($slotsForCollege) === 1 ? '' : 's' ?>
                </option>
                <?php foreach ($slotDateMap as $_d): ?>
                    <option value="<?= e($_d['date']) ?>" data-count="<?= (int)$_d['count'] ?>">
                        <?= format_date($_d['date']) ?><?= $_d['is_past'] ? ' (Past)' : '' ?>
                        · <?= (int)$_d['count'] ?> slot<?= (int)$_d['count'] === 1 ? '' : 's' ?>
                    </option>
                <?php endforeach; ?>
            </select>
        <?php endif; ?>
        <span id="es-slot-count">
            <?= count($slotsForCollege) ?> slot<?= count($slotsForCollege) === 1 ? '' : 's' ?>
            &nbsp;·&nbsp; <?= $totalFil ?> / <?= $totalCap ?> seats filled
        </span>
    </div>

    <div class="select-grid es-slot-grid">
        <?php foreach ($slotsForCollege as $slot):
            $sid       = (int)$slot['id'];
            $filled    = (int)$slot['filled'];
            $cap       = (int)$slot['capacity'];
            $isFull    = $filled >= $cap;
            $isPast    = $slot['exam_date'] < $today;
            $isToday   = $slot['exam_date'] === $today;

            $cardClass = 'select-card es-slot-card';
            if ($isToday) $cardClass .= ' is-today';
            if ($isPast)  $cardClass .= ' is-muted';
            if ($isFull)  $cardClass .= ' is-full';

            $editPayload = json_encode([
                'id'         => $sid,
                'exam_date'  => $slot['exam_date'],
                'slot_time'  => substr($slot['slot_time'] ?? '', 0, 5),
                'end_time'   => substr($slot['end_time']  ?? '', 0, 5),
                'room_label' => $slot['room_label'] ?? '',
                'department' => $slot['department'] ?? '',
                'capacity'   => $cap,
                'filled'     => $filled,
            ], JSON_HEX_APOS | JSON_HEX_QUOT);
            // Slots with applicants assigned can't be deleted in bulk either —
            // mirrors the single-row delete rule.
            $esUndeletable = $filled > 0;
            if ($esUndeletable) $cardClass .= ' is-undeletable';
        ?>
            <a href="<?= e(url('/staff/exam/slots') . '?slot=' . $sid) ?>"
               class="<?= $cardClass ?>"
               data-slot-id="<?= $sid ?>"
               data-date="<?= e($slot['exam_date'] ?? '') ?>"
               data-filled="<?= $filled ?>"
               data-capacity="<?= $cap ?>"
               onclick="return onEsCardClick(event, this)">
                <?php if ($canManage): ?>
                    <input type="checkbox" class="select-card-check es-select-checkbox"
                           value="<?= $sid ?>"
                           <?= $esUndeletable ? 'disabled title="Has applicants — cannot remove"' : '' ?>
                           onclick="event.stopPropagation();onEsCheckboxChange(this)">
                <?php endif; ?>

                <!-- Edit pencil — stops navigation to the roster -->
                <?php if ($canManage && !$isPast): ?>
                    <button type="button" class="es-card-edit-btn"
                            title="Edit slot"
                            onclick='event.preventDefault();event.stopPropagation();openEditExamSlot(<?= $editPayload ?>)'>
                        <?= icon('ic_fluent_edit_24_regular', 14) ?>
                    </button>
                <?php endif; ?>

                <!-- Status badge top-right (offset to leave room for edit button) -->
                <div class="select-card-badge<?= ($isPast || !$canManage) ? '' : ' has-edit' ?>">
                    <?php if ($isPast): ?>
                        <span class="badge badge-neutral">Ended</span>
                    <?php elseif ($isFull): ?>
                        <span class="badge badge-rejected">Full</span>
                    <?php elseif ($isToday): ?>
                        <span class="badge badge-info">Today</span>
                    <?php else: ?>
                        <span class="badge badge-approved">Open</span>
                    <?php endif; ?>
                </div>


                <div class="select-card-title">
                    <?= e($slot['room_label'] ?? '') ?>
                </div>

                <div class="select-card-meta">
                    <div class="select-card-meta-row">
                        <?= e(format_date($slot['exam_date'], 'D, M j, Y')) ?>
                    </div>
                    <div class="select-card-meta-row">
                        <?= e(format_time($slot['slot_time'])) ?>
                        <?php if (!empty($slot['end_time'])): ?>
                            &ndash; <?= e(format_time($slot['end_time'])) ?>
                        <?php endif; ?>
                    </div>
                    <div class="select-card-meta-row">
                        <strong style="<?= $isFull ? 'color:var(--error)' : 'color:var(--text-secondary)' ?>">
                            <?= $filled ?> / <?= $cap ?>
                        </strong>
                        seats filled
                    </div>
                    <?php
                        $cardSecsLeft = (int)($slot['pw_secs_left'] ?? 0);
                        $cardCodeActive = !empty($slot['access_password']) && $cardSecsLeft > 0;
                    ?>
                    <?php if ($cardCodeActive): ?>
                        <div class="select-card-meta-row">
                            Code
                            <span class="es-card-code-badge<?= $cardSecsLeft <= 60 ? ' is-warn' : '' ?>"
                                  data-card-pw-end="<?= time() + $cardSecsLeft ?>">
                                <?= e($slot['access_password']) ?>
                                · <span class="card-pw-timer"><?= gmdate('i:s', $cardSecsLeft) ?></span>
                            </span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="select-card-footer">
                    <span><?= e($slot['department']) ?></span>
                    <span class="select-card-action">
                        View
                    </span>
                </div>
            </a>
        <?php endforeach; ?>

        <?php if ($canManage): ?>
            <!-- Add Slot dashed card -->
            <div class="select-card select-card--add es-add-card"
                 role="button" tabindex="0"
                 onclick="document.getElementById('add-slot-modal').style.display='flex'"
                 onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();this.click();}">
                <div class="select-card-title">Add Slot</div>
                <div class="select-card-desc">Create a new exam room slot</div>
            </div>
        <?php endif; ?>
    </div>

    <?php if ($canManage && !empty($slotsForCollege)): ?>
    <!-- Floating bar for bulk delete (visible while in select mode). -->
    <div id="es-bulk-bar" class="select-bulk-bar es-bulk-bar">
        <span id="es-bulk-count" style="font-weight:var(--weight-medium)">0 selected</span>
        <form method="POST" id="es-bulk-form"
              style="display:flex;gap:var(--space-2);align-items:center;margin:0">
            <?= csrf_field() ?>
            <input type="hidden" name="action"      value="delete_slots_bulk">
            <input type="hidden" name="ctx_college" value="<?= e($collegeParam) ?>">
            <input type="hidden" name="ids"         id="es-bulk-ids" value="">
            <button type="button" class="btn btn-ghost btn-sm"
                    onclick="cancelEsSelectMode()">Cancel</button>
            <button type="submit" class="btn btn-sm" id="es-bulk-delete-btn"
                    style="background:var(--error);color:#fff;border-color:var(--error)"
                    onclick="return confirmEsBulkDelete()">
                Delete Selected
            </button>
        </form>
    </div>
    <?php endif; ?>



<?php elseif ($mode === 'roster'): ?>

    <!-- ============================================================
         MODE 3 — SLOT ROSTER (full-page table)
    ============================================================ -->
    <?php
    $sid       = (int)$slotDetail['id'];
    $filled    = (int)$slotDetail['filled'];
    $cap       = (int)$slotDetail['capacity'];
    $isPast    = $slotDetail['exam_date'] < date('Y-m-d');

    $editPayload = json_encode([
        'id'         => $sid,
        'exam_date'  => $slotDetail['exam_date'],
        'slot_time'  => substr($slotDetail['slot_time'] ?? '', 0, 5),
        'end_time'   => substr($slotDetail['end_time']  ?? '', 0, 5),
        'room_label' => $slotDetail['room_label'] ?? '',
        'department' => $slotDetail['department'] ?? '',
        'capacity'   => $cap,
        'filled'     => $filled,
    ], JSON_HEX_APOS | JSON_HEX_QUOT);
    ?>

    <!-- Slot summary strip -->
    <div style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);
                margin-bottom:var(--space-4);background:var(--bg-elevated);border:1px solid var(--border);
                border-radius:var(--radius);font-size:var(--text-sm);flex-wrap:wrap;flex-shrink:0">
        <?= icon('ic_fluent_location_24_regular', 14, 'color:var(--text-tertiary);flex-shrink:0') ?>

        <?php if ($canManage && !$isPast): ?>
            <!-- Inline-editable room label (Admin/SSO only). Click the pencil to rename. -->
            <span id="room-label-view" style="display:inline-flex;align-items:center;gap:6px">
                <span id="room-label-text" style="font-weight:var(--weight-medium)"><?= e($slotDetail['room_label']) ?></span>
                <button type="button" class="btn-icon" title="Rename room"
                        onclick="startRoomLabelEdit()"
                        style="padding:2px;color:var(--text-tertiary)">
                    <?= icon('ic_fluent_edit_24_regular', 12) ?>
                </button>
            </span>
            <span id="room-label-edit" style="display:none;align-items:center;gap:4px">
                <input type="text" id="room-label-input" class="form-control"
                       value="<?= e($slotDetail['room_label']) ?>"
                       maxlength="80"
                       style="font-size:var(--text-sm);padding:2px 8px;height:auto;min-height:0;width:240px">
                <button type="button" class="btn btn-primary btn-sm"
                        onclick="saveRoomLabel(<?= $sid ?>)"
                        style="font-size:var(--text-xs);padding:2px 8px;height:auto;min-height:0">Save</button>
                <button type="button" class="btn btn-ghost btn-sm"
                        onclick="cancelRoomLabelEdit()"
                        style="font-size:var(--text-xs);padding:2px 8px;height:auto;min-height:0">Cancel</button>
            </span>
        <?php else: ?>
            <span style="font-weight:var(--weight-medium)"><?= e($slotDetail['room_label']) ?></span>
        <?php endif; ?>

        <span style="color:var(--text-tertiary)">
            <?= e(format_date($slotDetail['exam_date'], 'D, M j, Y')) ?>
            · <?= e(format_time($slotDetail['slot_time'])) ?><?php if (!empty($slotDetail['end_time'])): ?>–<?= e(format_time($slotDetail['end_time'])) ?><?php endif; ?>
            · <?= e($slotDetail['department']) ?>
        </span>
        <span style="margin-left:auto;font-size:var(--text-xs);color:var(--text-tertiary)">
            <strong style="<?= $filled >= $cap ? 'color:var(--error)' : '' ?>">
                <?= $filled ?> / <?= $cap ?>
            </strong>
            seats filled
            <?php if ($isPast): ?>
                <span class="badge badge-neutral" style="margin-left:var(--space-2)">Ended</span>
            <?php endif; ?>
        </span>
    </div>

    <?php
        $rosterCanGenerate = $canGenerateCodeFor((string) $slotDetail['department']);
        $rosterSecsLeft    = (int)($slotDetail['pw_secs_left'] ?? 0);
        $rosterCodeActive  = !empty($slotDetail['access_password']) && $rosterSecsLeft > 0;
    ?>

    <!-- ============================================================
         Per-room access code panel
         (proctor-facing: announce the code to the room and start the
         5-minute window. Read-only for Dean and out-of-dept staff.)
    ============================================================ -->
    <?php if (!$isPast): ?>
    <div class="es-code-panel" id="slot-code-panel" data-slot-id="<?= $sid ?>">
        <span class="es-code-panel-label">
            <?= icon('ic_fluent_lock_closed_24_regular', 14) ?>
            Access Code
        </span>

        <span id="slot-code-display"
              class="es-code-display<?= $rosterCodeActive ? '' : ' is-empty' ?>">
            <?= $rosterCodeActive ? e($slotDetail['access_password']) : 'No active code' ?>
        </span>

        <span id="slot-code-timer" class="es-code-timer"
              style="<?= $rosterCodeActive ? '' : 'display:none' ?>"
              data-secs-left="<?= $rosterSecsLeft ?>">
            Expires in <?= gmdate('i:s', $rosterSecsLeft) ?>
        </span>

        <?php if ($rosterCanGenerate): ?>
            <div style="margin-left:auto;display:flex;gap:var(--space-2)">
                <button type="button" id="slot-code-extend-btn"
                        class="btn btn-ghost btn-sm"
                        onclick="extendSlotCode()"
                        style="<?= $rosterCodeActive ? '' : 'display:none' ?>;font-size:var(--text-xs)">
                    <?= icon('ic_fluent_clock_24_regular', 12) ?> Extend
                </button>
                <button type="button" id="slot-code-generate-btn"
                        class="btn btn-primary btn-sm"
                        onclick="generateSlotCode()"
                        style="<?= $rosterCodeActive ? '' : 'display:none' ?>;font-size:var(--text-xs)">
                    <?= icon('ic_fluent_arrow_sync_24_regular', 12) ?> New
                </button>
            </div>
        <?php else: ?>
            <span style="margin-left:auto;font-size:var(--text-xs);color:var(--text-tertiary)">
                <?= icon('ic_fluent_eye_24_regular', 12) ?> Read-only
            </span>
        <?php endif; ?>
    </div>
    <div style="font-size:var(--text-xs);color:var(--text-tertiary);margin:-2px 0 var(--space-4) 2px;flex-shrink:0">
        <?php if ($rosterCodeActive): ?>
            Codes are valid for 5 minutes. Use <strong>Extend</strong> to give late
            but legitimate applicants another 5 minutes from now, or <strong>New</strong>
            to issue a fresh password and invalidate the current one.
        <?php elseif ($rosterCanGenerate): ?>
            A fresh access code is issued automatically the moment you open this
            page on the slot's exam date. After that, use <strong>New</strong> or
            <strong>Extend</strong> to manage the 5-minute window.
        <?php else: ?>
            Codes are valid for 5 minutes and are issued by this room's proctor.
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php
    // URL helper — keeps the slot + current filters + per_page while overriding
    // just the given keys (page links, the Clear link). Same shape as the audit
    // log's auditUrl().
    $rosterUrl = function (array $merge = []) use ($sid, $rosterSearch, $rosterType, $rosterPerPage): string {
        $base = [
            'slot'     => $sid,
            'q'        => $rosterSearch,
            'type'     => $rosterType,
            'per_page' => $rosterPerPage,
            'page'     => 1,
        ];
        return url('/staff/exam/slots') . '?' . http_build_query(array_filter(
            array_merge($base, $merge),
            fn($v) => $v !== '' && $v !== null
        ));
    };
    $rosterHasFilters = ($rosterSearch !== '' || $rosterType !== '');
    $collegeUrl       = url('/staff/exam/slots') . '?college=' . urlencode($slotDetail['department']);
    ?>

    <?php
    // Same structure as the audit log (and lakbay-pasig's AdminDataTable): one
    // .auto-table-wrap that AutoPageSize measures, the card with the toolbar and
    // the fixed-height table fused together, and the pagination bar under the card.
    ?>
    <div class="auto-table-wrap" data-auto-page-size="exam-slot-roster" data-current-per-page="<?= (int)$rosterPerPage ?>">

    <div class="auto-table-card">

        <!-- Toolbar: search + filter, one row, inside the card -->
        <form method="GET" action="<?= e(url('/staff/exam/slots')) ?>" class="auto-table-toolbar">
            <input type="hidden" name="slot"     value="<?= $sid ?>">
            <input type="hidden" name="per_page" value="<?= (int)$rosterPerPage ?>">

            <div class="auto-table-search">
                <?= icon('ic_fluent_search_24_filled', 14) ?>
                <input type="text" name="q" class="form-input" placeholder="Search name, email, course…" value="<?= e($rosterSearch) ?>">
            </div>

            <select name="type" class="form-input" style="width:160px" onchange="this.form.submit()" aria-label="Applicant type">
                <option value="">All Types</option>
                <option value="freshman"   <?= $rosterType === 'freshman'   ? 'selected' : '' ?>>Freshman</option>
                <option value="transferee" <?= $rosterType === 'transferee' ? 'selected' : '' ?>>Transferee</option>
                <option value="foreign"    <?= $rosterType === 'foreign'    ? 'selected' : '' ?>>Foreign Student</option>
            </select>

            <?php if ($rosterHasFilters): ?>
                <a href="<?= e($rosterUrl(['q' => '', 'type' => '', 'page' => 1])) ?>" class="btn btn-ghost btn-sm">Clear</a>
            <?php endif; ?>
        </form>

        <!-- Table body — sized so the rows AutoPageSize picks fit exactly; it
             only scrolls as a safety net (e.g. a very narrow window) -->
        <div class="auto-table-body">
            <table class="auto-table">
                <thead>
                    <tr>
                        <th style="min-width:220px">Applicant</th>
                        <th style="width:240px">Email</th>
                        <th style="width:240px">Course</th>
                        <th style="width:120px">Type</th>
                        <th style="width:160px">Assigned</th>
                        <?php if ($canManage && !$isPast): ?>
                            <th style="width:100px">Action</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <?php if (!empty($slotRoster)): ?>
                <tbody>
                <?php foreach ($slotRoster as $row): ?>
                    <tr>
                        <td style="font-size:var(--text-sm)" title="<?= e(format_full_name($row)) ?>">
                            <span class="auto-table-clip" style="font-weight:var(--weight-medium)"><?= e(format_full_name($row)) ?></span>
                        </td>
                        <td style="font-size:var(--text-xs);color:var(--text-tertiary)" title="<?= e($row['student_email'] ?? '') ?>">
                            <span class="auto-table-clip"><?= e(!empty($row['student_email']) ? $row['student_email'] : '—') ?></span>
                        </td>
                        <td style="font-size:var(--text-sm)" title="<?= e($row['course_applied'] ?? '') ?>">
                            <span class="auto-table-clip"><?= e($row['course_applied'] ?: '—') ?></span>
                        </td>
                        <td>
                            <span class="badge badge-neutral">
                                <?= e(ucfirst($row['applicant_type'] ?? '')) ?>
                            </span>
                        </td>
                        <td style="font-size:var(--text-xs);color:var(--text-tertiary)">
                            <span class="auto-table-clip">
                            <?= $row['assigned_at']
                                ? e(date('M j, g:i A', strtotime($row['assigned_at'])))
                                : '—' ?>
                            </span>
                        </td>
                        <?php if ($canManage && !$isPast): ?>
                            <td>
                                <form method="POST" style="margin:0"
                                      onsubmit="return confirm('Remove this applicant from the slot?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action"       value="unassign">
                                    <input type="hidden" name="ctx_slot"     value="<?= $sid ?>">
                                    <input type="hidden" name="applicant_id" value="<?= (int)$row['applicant_id'] ?>">
                                    <button type="submit" class="btn btn-ghost btn-sm"
                                            style="color:var(--error);font-size:var(--text-xs)">
                                        Remove
                                    </button>
                                </form>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
                <?php endif; ?>
            </table>

            <?php if (empty($slotRoster)): ?>
            <div class="auto-table-empty">
                <?= icon('ic_fluent_people_24_regular', 32) ?>
                <?php if ($rosterHasFilters): ?>
                    <div>No applicants match your filters.</div>
                <?php else: ?>
                    <div style="max-width:420px">
                        No applicants assigned to this slot yet. Use the
                        <a href="<?= e($collegeUrl) ?>">college view</a>
                        to assign applicants from the awaiting list.
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div><!-- /.auto-table-card -->

    <!-- Pagination bar — under the card, inside the wrap. Its 40px is reserved in
         AutoPageSize's math whether or not it renders. -->
    <?php if ($rosterResult['last_page'] > 1): ?>
        <?= auto_table_footer($rosterResult, fn(int $p): string => $rosterUrl(['page' => $p]), 'applicants') ?>
    <?php endif; ?>

    </div><!-- /.auto-table-wrap -->

<?php endif; ?>


<!-- ============================================================
     MODALS — shared across all modes that may need them.
============================================================ -->

<?php if ($mode !== 'colleges'): ?>

    <!-- ── Add Slot Modal (Single + Recurring) ────────────────── -->
    <div id="add-slot-modal" class="modal-backdrop" style="display:none">
        <div class="modal" style="max-width:480px">
            <div class="modal-header">
                <div class="modal-title">Add Slot</div>
                <button class="btn-icon" type="button"
                        onclick="document.getElementById('add-slot-modal').style.display='none'">
                    <?= icon('ic_fluent_dismiss_24_regular', 16) ?>
                </button>
            </div>
            <form method="POST" id="add-slot-form">
                <?= csrf_field() ?>
                <input type="hidden" name="action"      id="add-slot-action" value="add_slot">
                <input type="hidden" name="ctx_college" value="<?= e($collegeParam) ?>">
                <div class="modal-body" style="display:flex;flex-direction:column;gap:var(--space-4)">

                    <!-- Mode toggle -->
                    <div class="seg-control" style="align-self:flex-start">
                        <button type="button" id="add-slot-mode-single"
                                class="seg-control-item active"
                                onclick="setSlotMode('single')">Single slot</button>
                        <button type="button" id="add-slot-mode-batch"
                                class="seg-control-item"
                                onclick="setSlotMode('batch')">Recurring (multiple)</button>
                    </div>

                    <!-- College is taken from the page context (?college=…). The
                         JS toggle swaps this hidden input's `name` between
                         `department` and `batch_department` so the two POST
                         handlers stay unchanged. -->
                    <input type="hidden" id="add-slot-dept" name="department"
                           value="<?= e($canManage ? $collegeParam : $staffDept) ?>">

                    <!-- ── Single slot fields ─────────────────── -->
                    <div id="add-slot-single-fields" style="display:flex;flex-direction:column;gap:var(--space-4)">
                        <div>
                            <label class="form-label">Exam Date <span style="color:var(--error)">*</span></label>
                            <input type="date" name="exam_date" class="form-control" required
                                   value="<?= e($defaultDate) ?>" min="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="row row-cols-1 row-cols-md-2" style="--bs-gutter-x:var(--space-3);--bs-gutter-y:var(--space-3)">
                            <div>
                                <label class="form-label">Opens <span style="color:var(--error)">*</span></label>
                                <input type="time" name="slot_time" id="add-slot-time"
                                       class="form-control" value="08:00" required>
                            </div>
                            <div>
                                <label class="form-label">Closes <span style="color:var(--error)">*</span></label>
                                <input type="time" name="end_time" id="add-slot-end"
                                       class="form-control" value="09:30" required>
                            </div>
                        </div>
                        <div class="row row-cols-1 row-cols-md-2" style="--bs-gutter-x:var(--space-3);--bs-gutter-y:var(--space-3)">
                            <div>
                                <label class="form-label">Capacity <span style="color:var(--error)">*</span></label>
                                <input type="number" name="capacity" class="form-control"
                                       value="<?= $examRoomCap ?>" min="1" max="500" required>
                            </div>
                            <div>
                                <label class="form-label">Room Label <span style="color:var(--error)">*</span></label>
                                <input type="text" name="room_label" class="form-control" required
                                       placeholder="e.g. Room 101" maxlength="80">
                            </div>
                        </div>
                    </div>

                    <!-- ── Recurring (batch) fields ───────────── -->
                    <div id="add-slot-batch-fields" style="display:none;flex-direction:column;gap:var(--space-4)">
                        <p style="font-size:var(--text-sm);color:var(--text-secondary);margin:0">
                            One slot is created per room per selected weekday in the date range.
                        </p>
                        <div class="row row-cols-1 row-cols-md-2" style="--bs-gutter-x:var(--space-3);--bs-gutter-y:var(--space-3)">
                            <div>
                                <label class="form-label">Start Date <span style="color:var(--error)">*</span></label>
                                <input type="date" name="batch_start_date" class="form-control"
                                       value="<?= e($defaultDate) ?>" required>
                            </div>
                            <div>
                                <label class="form-label">End Date <span style="color:var(--error)">*</span></label>
                                <input type="date" name="batch_end_date" class="form-control"
                                       value="<?= e(date('Y-m-d', strtotime($defaultDate . ' +6 days'))) ?>" required>
                            </div>
                        </div>
                        <div class="row row-cols-1 row-cols-md-2" style="--bs-gutter-x:var(--space-3);--bs-gutter-y:var(--space-3)">
                            <div>
                                <label class="form-label">Opens <span style="color:var(--error)">*</span></label>
                                <input type="time" name="batch_time" id="batch-time"
                                       class="form-control" value="08:00" required>
                            </div>
                            <div>
                                <label class="form-label">Closes <span style="color:var(--error)">*</span></label>
                                <input type="time" name="batch_end_time" id="batch-end-time"
                                       class="form-control" value="09:30" required>
                            </div>
                        </div>
                        <div>
                            <label class="form-label">Seats per Slot</label>
                            <input type="number" name="batch_capacity" class="form-control"
                                   value="<?= $examRoomCap ?>" min="1" max="500">
                        </div>
                        <div>
                            <label class="form-label">Rooms</label>
                            <div id="batch-rooms-list" style="display:flex;flex-direction:column;gap:var(--space-2)">
                                <input type="text" name="batch_rooms[]" class="form-control"
                                       placeholder="e.g. Room 101" required>
                            </div>
                            <button type="button" class="btn btn-ghost btn-sm"
                                    style="margin-top:var(--space-2);font-size:var(--text-xs)"
                                    onclick="addBatchRoom()">+ Add another room</button>
                        </div>
                        <div>
                            <label class="form-label">Days of Week</label>
                            <div style="display:flex;flex-wrap:wrap;gap:var(--space-2)">
                                <?php foreach ([1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat',0=>'Sun'] as $dv => $dl): ?>
                                    <label style="display:flex;align-items:center;gap:4px;font-size:var(--text-sm)">
                                        <input type="checkbox" name="batch_days[]" value="<?= $dv ?>"
                                            <?= $dv >= 1 && $dv <= 5 ? 'checked' : '' ?>>
                                        <?= $dl ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <div style="font-size:var(--text-xs);color:var(--text-tertiary);margin-top:-2px">
                        Exam closes at <strong>Closes</strong>. Duration is the difference between the two.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-ghost"
                            onclick="document.getElementById('add-slot-modal').style.display='none'">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="add-slot-submit">Add Slot</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ── Edit Slot Modal ────────────────────────────────────── -->
    <div id="edit-slot-modal" class="modal-backdrop" style="display:none">
        <div class="modal" style="max-width:420px">
            <div class="modal-header">
                <div class="modal-title">Edit Slot</div>
                <button class="btn-icon" type="button"
                        onclick="document.getElementById('edit-slot-modal').style.display='none'">
                    <?= icon('ic_fluent_dismiss_24_regular', 16) ?>
                </button>
            </div>
            <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action"      value="edit_slot">
                <input type="hidden" name="ctx_college" value="<?= e($collegeParam) ?>">
                <input type="hidden" name="ctx_slot"    id="edit-slot-ctx-slot" value="<?= $slotIdParam ?: '' ?>">
                <input type="hidden" name="slot_id"     id="edit-slot-id">
                <div class="modal-body" style="display:flex;flex-direction:column;gap:var(--space-4)">
                    <div>
                        <label class="form-label">College / Department <span style="color:var(--error)">*</span></label>
                        <?php if ($canManage): ?>
                            <select name="department" id="edit-slot-dept" class="form-control" required>
                                <option value="">— Select college —</option>
                                <?php foreach ($departments as $dept): ?>
                                    <option value="<?= e($dept) ?>"><?= e($dept) ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php else: ?>
                            <input type="text" class="form-control" value="<?= e($staffDept ?: 'Not assigned') ?>" disabled>
                            <input type="hidden" name="department" value="<?= e($staffDept) ?>">
                        <?php endif; ?>
                    </div>
                    <div>
                        <label class="form-label">Exam Date <span style="color:var(--error)">*</span></label>
                        <input type="date" name="exam_date" id="edit-slot-date"
                               class="form-control" required min="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="row row-cols-1 row-cols-md-2" style="--bs-gutter-x:var(--space-3);--bs-gutter-y:var(--space-3)">
                        <div>
                            <label class="form-label">Opens <span style="color:var(--error)">*</span></label>
                            <input type="time" name="slot_time" id="edit-slot-time" class="form-control" required>
                        </div>
                        <div>
                            <label class="form-label">Closes <span style="color:var(--error)">*</span></label>
                            <input type="time" name="end_time" id="edit-slot-end" class="form-control" required>
                        </div>
                    </div>
                    <div style="font-size:var(--text-xs);color:var(--text-tertiary);margin-top:-2px">
                        Exam closes at <strong>Closes</strong>. Duration is the difference between the two.
                    </div>
                    <div class="row row-cols-1 row-cols-md-2" style="--bs-gutter-x:var(--space-3);--bs-gutter-y:var(--space-3)">
                        <div>
                            <label class="form-label">Capacity <span style="color:var(--error)">*</span></label>
                            <input type="number" name="capacity" id="edit-slot-cap"
                                   class="form-control" min="1" max="500" required>
                        </div>
                        <div>
                            <label class="form-label">Room Label <span style="color:var(--error)">*</span></label>
                            <input type="text" name="room_label" id="edit-slot-room"
                                   class="form-control" required maxlength="80">
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="justify-content:space-between">
                    <?php // Inline delete (only when slot is empty — server still validates) ?>
                    <button type="submit" form="delete-slot-form" class="btn btn-ghost"
                            id="edit-slot-delete-btn"
                            style="color:var(--error)"
                            onclick="return confirm('Delete this slot? Only allowed if it has no applicants.')">
                        Delete
                    </button>
                    <div style="display:flex;gap:var(--space-2)">
                        <button type="button" class="btn btn-ghost"
                                onclick="document.getElementById('edit-slot-modal').style.display='none'">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </div>
            </form>
            <!-- Out-of-form delete: just submits action=delete_slot for the same slot id -->
            <form method="POST" id="delete-slot-form" style="display:none">
                <?= csrf_field() ?>
                <input type="hidden" name="action"      value="delete_slot">
                <input type="hidden" name="ctx_college" value="<?= e($collegeParam) ?>">
                <input type="hidden" name="slot_id"     id="delete-slot-id">
            </form>
        </div>
    </div>

    <!-- ── Exam Config Modal ──────────────────────────────────── -->
    <div id="exam-config-modal" class="modal-backdrop" style="display:none">
        <div class="modal" style="max-width:420px">
            <div class="modal-header">
                <div class="modal-title">Exam Config</div>
                <button class="btn-icon" type="button"
                        onclick="document.getElementById('exam-config-modal').style.display='none'">
                    <?= icon('ic_fluent_dismiss_24_regular', 16) ?>
                </button>
            </div>
            <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action"      value="update_exam_config">
                <input type="hidden" name="ctx_college" value="<?= e($collegeParam) ?>">
                <div class="modal-body" style="display:flex;flex-direction:column;gap:var(--space-4)">
                    <div>
                        <label class="form-label">Default Seats per Room</label>
                        <input type="number" name="exam_room_capacity" class="form-control"
                               value="<?= $examRoomCap ?>" min="1" max="200">
                    </div>
                    <div>
                        <label class="form-label">Max Applicants per Exam Day</label>
                        <input type="number" name="exam_daily_cap" class="form-control"
                               value="<?= $examDailyCap ?>" min="1" max="10000">
                    </div>
                    <?php $roomsNeeded = $examRoomCap > 0 ? ceil($examDailyCap / $examRoomCap) : '—'; ?>
                    <div style="background:var(--bg-subtle);border-radius:var(--radius);
                                padding:var(--space-3) var(--space-4);font-size:var(--text-xs);
                                color:var(--text-secondary)">
                        <?= $examDailyCap ?> applicants &divide; <?= $examRoomCap ?>/room
                        = <strong>~<?= $roomsNeeded ?> rooms/day</strong>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-ghost"
                            onclick="document.getElementById('exam-config-modal').style.display='none'">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Config</button>
                </div>
            </form>
        </div>
    </div>


<?php endif; ?>

<script>
['add-slot-modal','exam-config-modal','edit-slot-modal'].forEach(function(id){
    var m = document.getElementById(id);
    if (m) m.addEventListener('click', function (e) { if (e.target === this) this.style.display = 'none'; });
});

// ── Date filter on the slot card grid ────────────────────────
// Mirrors the interview queue's date dropdown (see staff_queue.php).
// Pure client-side: hide cards whose data-date doesn't match the
// selected value, then rebuild the "N slots · X / Y seats filled"
// summary line so the badge always reflects what's visible.
(function() {
    var dateEl  = document.getElementById('es-date-filter');
    var countEl = document.getElementById('es-slot-count');
    if (!dateEl) return;

    function applyEsDateFilter() {
        var picked  = dateEl.value;
        var visible = 0, filled = 0, capacity = 0;
        document.querySelectorAll('.es-slot-grid .es-slot-card').forEach(function(card) {
            var d = card.getAttribute('data-date') || '';
            var match = !picked || d === picked;
            card.style.display = match ? '' : 'none';
            if (match) {
                visible++;
                filled   += parseInt(card.getAttribute('data-filled')   || '0', 10);
                capacity += parseInt(card.getAttribute('data-capacity') || '0', 10);
            }
        });
        if (countEl) {
            countEl.innerHTML = visible + ' slot' + (visible === 1 ? '' : 's')
                + ' \u00a0\u00b7\u00a0 ' + filled + ' / ' + capacity + ' seats filled';
        }
    }
    dateEl.addEventListener('change', applyEsDateFilter);
})();

// ── Bulk select mode for exam slot cards ─────────────────────
// Shared "select mode" logic lives in createCardBulkSelector()
// (public/assets/js/app.js), which loads after this inline block.
// _esSelector() builds it lazily on first call instead of at parse
// time, so load order doesn't matter. These wrappers keep the same
// global names the markup already calls via onclick=, so no HTML
// changed.
var __esSelectorInstance = null;
function _esSelector() {
    if (!__esSelectorInstance) {
        __esSelectorInstance = createCardBulkSelector({
            gridSel:     '.es-slot-grid',
            cardSel:     '.es-slot-card',
            checkboxSel: '.es-select-checkbox',
            barId:       'es-bulk-bar',
            toggleBtnId: 'es-select-toggle',
            countId:     'es-bulk-count',
            deleteBtnId: 'es-bulk-delete-btn',
            idsInputId:  'es-bulk-ids',
            confirmMsg:  function (n) { return 'Remove ' + n + ' slot(s)? This cannot be undone.'; },
        });
    }
    return __esSelectorInstance;
}
function _esGrid()              { return document.querySelector('.es-slot-grid'); }
function toggleEsSelectMode()   { _esSelector().toggleSelectMode(); }
function cancelEsSelectMode()   { _esSelector().cancelSelectMode(); }
function onEsCheckboxChange(cb) { _esSelector().onCheckboxChange(cb); }
function updateEsBulkCount()    { _esSelector().updateCount(); }
function confirmEsBulkDelete()  { return _esSelector().confirmBulkDelete(); }
function onEsCardClick(event, link) {
    var grid = _esGrid();
    if (grid && grid.classList.contains('is-selecting')) {
        // While selecting, the card toggles its checkbox instead of navigating
        // to the roster. Disabled (filled) cards do nothing.
        event.preventDefault();
        var cb = link.querySelector('.es-select-checkbox');
        if (cb && !cb.disabled) {
            cb.checked = !cb.checked;
            onEsCheckboxChange(cb);
        }
        return false;
    }
    return true;
}

// When the user changes the open time, auto-bump the close time to
// open + 90 minutes — but only if they haven't manually moved the
// close field yet (so we don't overwrite an explicit close on edit).
function _autoEnd(openId, closeId) {
    var openEl  = document.getElementById(openId);
    var closeEl = document.getElementById(closeId);
    if (!openEl || !closeEl) return;
    closeEl.addEventListener('input', function () { closeEl.dataset.userset = '1'; });
    openEl.addEventListener('change', function () {
        if (closeEl.dataset.userset === '1') return;
        var parts = (openEl.value || '').split(':');
        if (parts.length !== 2) return;
        var d = new Date();
        d.setHours(parseInt(parts[0], 10) || 0, (parseInt(parts[1], 10) || 0) + 90, 0, 0);
        var hh = String(d.getHours()).padStart(2, '0');
        var mm = String(d.getMinutes()).padStart(2, '0');
        closeEl.value = hh + ':' + mm;
    });
}
_autoEnd('add-slot-time',   'add-slot-end');
_autoEnd('edit-slot-time',  'edit-slot-end');
_autoEnd('batch-time',      'batch-end-time');

// ── Add Slot modal: Single / Recurring toggle ────────────────
function setSlotMode(mode) {
    var single = document.getElementById('add-slot-single-fields');
    var batch  = document.getElementById('add-slot-batch-fields');
    var btnS   = document.getElementById('add-slot-mode-single');
    var btnB   = document.getElementById('add-slot-mode-batch');
    var action = document.getElementById('add-slot-action');
    var submit = document.getElementById('add-slot-submit');
    var dept   = document.getElementById('add-slot-dept');
    if (!single || !batch) return;

    var isBatch = mode === 'batch';
    single.style.display = isBatch ? 'none' : 'flex';
    batch.style.display  = isBatch ? 'flex' : 'none';
    if (btnS) btnS.classList.toggle('active', !isBatch);
    if (btnB) btnB.classList.toggle('active',  isBatch);
    if (action) action.value = isBatch ? 'batch_create_slots' : 'add_slot';
    if (submit) submit.textContent = isBatch ? 'Create Slots' : 'Add Slot';

    // Disable inputs in the inactive block so they don't post and don't
    // block submission via HTML5 `required` validation.
    document.querySelectorAll('#add-slot-single-fields [name]').forEach(function(el){ el.disabled = isBatch; });
    document.querySelectorAll('#add-slot-batch-fields  [name]').forEach(function(el){ el.disabled = !isBatch; });

    // The shared College/Department field posts as `department` for the
    // single-slot handler and `batch_department` for the batch handler.
    if (dept) dept.name = isBatch ? 'batch_department' : 'department';
}
document.addEventListener('DOMContentLoaded', function(){ setSlotMode('single'); });

function addBatchRoom() {
    var list = document.getElementById('batch-rooms-list');
    if (!list) return;
    var wrapper = document.createElement('div');
    wrapper.style.cssText = 'display:flex;gap:var(--space-2);align-items:center';

    var input = document.createElement('input');
    input.type        = 'text';
    input.name        = 'batch_rooms[]';
    input.className   = 'form-control';
    input.placeholder = 'e.g. Room 102';
    input.required    = true;
    input.style.flex  = '1';

    var removeBtn = document.createElement('button');
    removeBtn.type      = 'button';
    removeBtn.className = 'btn-icon';
    removeBtn.title     = 'Remove';
    removeBtn.style.cssText = 'color:var(--error);padding:var(--space-1);flex-shrink:0';
    removeBtn.innerHTML = '&times;';
    removeBtn.onclick   = function () { wrapper.remove(); };

    wrapper.appendChild(input);
    wrapper.appendChild(removeBtn);
    list.appendChild(wrapper);
    input.focus();
}

function openEditExamSlot(payload) {
    if (!payload) return;
    document.getElementById('edit-slot-id').value   = payload.id;
    document.getElementById('edit-slot-date').value = payload.exam_date;
    document.getElementById('edit-slot-time').value = payload.slot_time || '';
    document.getElementById('edit-slot-end').value  = payload.end_time  || '';
    document.getElementById('edit-slot-room').value = payload.room_label || '';
    document.getElementById('edit-slot-cap').value  = payload.capacity || '';

    var deptSel = document.getElementById('edit-slot-dept');
    if (deptSel) deptSel.value = payload.department || '';

    // Wire the inline delete button to the same slot id
    var delIn = document.getElementById('delete-slot-id');
    if (delIn) delIn.value = payload.id;
    var delBtn = document.getElementById('edit-slot-delete-btn');
    if (delBtn) {
        delBtn.disabled = (parseInt(payload.filled, 10) || 0) > 0;
        delBtn.title    = delBtn.disabled
            ? 'Cannot delete a slot with applicants assigned. Unassign them first.'
            : '';
    }

    document.getElementById('edit-slot-modal').style.display = 'flex';
}

// ── Per-room access code (Chunk 7) ────────────────────────────
//
// Drives the proctor-facing code panel on the slot roster page,
// plus the small "code active" badge on the college slot grid.

function _csrfPair() {
    var i = document.querySelector('input[name^="_csrf"]');
    return i ? { name: i.name, value: i.value } : null;
}

function _formatMMSS(s) {
    if (s < 0) s = 0;
    var m = Math.floor(s / 60);
    var r = s % 60;
    return (m < 10 ? '0' : '') + m + ':' + (r < 10 ? '0' : '') + r;
}

// Roster countdown — single slot, controls visible if you can generate
var _slotCodeTimer = null;
function startSlotCodeCountdown(secsLeft) {
    if (_slotCodeTimer) clearInterval(_slotCodeTimer);
    var timerEl   = document.getElementById('slot-code-timer');
    var displayEl = document.getElementById('slot-code-display');
    var extendBtn = document.getElementById('slot-code-extend-btn');
    var genBtn    = document.getElementById('slot-code-generate-btn');
    if (!timerEl) return;

    function render(s) {
        timerEl.classList.remove('is-warn', 'is-expired');
        if (s > 0) {
            timerEl.style.display = '';
            timerEl.textContent = 'Expires in ' + _formatMMSS(s);
            if (s <= 60) timerEl.classList.add('is-warn');
            if (extendBtn) extendBtn.style.display = 'inline-flex';
            if (genBtn)    genBtn.style.display    = 'inline-flex';
        } else {
            timerEl.style.display = '';
            timerEl.textContent = 'Expired — reissuing…';
            timerEl.classList.add('is-expired');
            if (displayEl) {
                displayEl.classList.add('is-empty');
                displayEl.textContent = 'No active code';
            }
            if (extendBtn) extendBtn.style.display = 'none';
            if (genBtn)    genBtn.style.display    = 'none';
        }
    }
    render(secsLeft);
    if (secsLeft > 0) {
        _slotCodeTimer = setInterval(function () {
            secsLeft--;
            render(secsLeft);
            if (secsLeft <= 0) {
                clearInterval(_slotCodeTimer); _slotCodeTimer = null;
                // Auto-refresh so the server-side auto-issue logic on
                // staff_slots.php picks up where we left off and rolls
                // a fresh 5-minute code without proctor intervention.
                setTimeout(function () { location.reload(); }, 800);
            }
        }, 1000);
    }
}

// Auto-start the roster countdown if the page rendered with an active code.
(function () {
    var t = document.getElementById('slot-code-timer');
    if (!t) return;
    var s = parseInt(t.getAttribute('data-secs-left') || '0', 10);
    if (s > 0) startSlotCodeCountdown(s);
})();

async function _postSlotCodeAction(action) {
    var panel = document.getElementById('slot-code-panel');
    if (!panel) return;
    var slotId = panel.getAttribute('data-slot-id');
    var csrf   = _csrfPair();
    if (!csrf) return alert('Missing CSRF token. Please reload the page.');

    var fd = new FormData();
    fd.append('action', action);
    fd.append('slot_id', slotId);
    fd.append(csrf.name, csrf.value);

    try {
        var resp = await fetch(location.href, {
            method: 'POST', body: fd,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        var d = await resp.json();
        if (!d.ok) { alert(d.error || 'Could not update code.'); return; }

        var displayEl = document.getElementById('slot-code-display');
        if (displayEl) {
            displayEl.classList.remove('is-empty');
            displayEl.textContent = d.password;
        }
        startSlotCodeCountdown(d.expires_in);
    } catch (e) {
        alert('Network error. Try again.');
    }
}

function generateSlotCode() {
    if (document.getElementById('slot-code-display') &&
        !document.getElementById('slot-code-display').classList.contains('is-empty')) {
        if (!confirm('Issue a new code? The current code will be replaced immediately and applicants who have not yet entered the old code will be locked out.')) return;
    }
    _postSlotCodeAction('generate_slot_code');
}
function extendSlotCode() { _postSlotCodeAction('extend_slot_code'); }

// Inline edit of room label on the roster page
function startRoomLabelEdit() {
    var v = document.getElementById('room-label-view');
    var e = document.getElementById('room-label-edit');
    if (!v || !e) return;
    v.style.display = 'none';
    e.style.display = 'inline-flex';
    var inp = document.getElementById('room-label-input');
    if (inp) { inp.focus(); inp.select(); }
}
function cancelRoomLabelEdit() {
    var v = document.getElementById('room-label-view');
    var e = document.getElementById('room-label-edit');
    if (!v || !e) return;
    e.style.display = 'none';
    v.style.display = 'inline-flex';
}
async function saveRoomLabel(slotId) {
    var inp = document.getElementById('room-label-input');
    if (!inp) return;
    var newLabel = inp.value.trim();
    if (!newLabel) { alert('Room label cannot be empty.'); return; }

    var csrf = _csrfPair();
    if (!csrf) return alert('Missing CSRF token. Please reload the page.');

    var fd = new FormData();
    fd.append('action', 'update_room_label');
    fd.append('slot_id', slotId);
    fd.append('room_label', newLabel);
    fd.append(csrf.name, csrf.value);

    try {
        var resp = await fetch(location.href, {
            method: 'POST', body: fd,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        var d = await resp.json();
        if (!d.ok) { alert(d.error || 'Could not rename room.'); return; }
        var t = document.getElementById('room-label-text');
        if (t) t.textContent = d.room_label;
        cancelRoomLabelEdit();
    } catch (e) {
        alert('Network error. Try again.');
    }
}

// Card-grid badges — per-card lightweight countdowns, no buttons.
(function () {
    var badges = document.querySelectorAll('[data-card-pw-end]');
    if (!badges.length) return;
    function tick() {
        var now = Math.floor(Date.now() / 1000);
        badges.forEach(function (b) {
            var endTs = parseInt(b.getAttribute('data-card-pw-end') || '0', 10);
            var left  = Math.max(0, endTs - now);
            var t = b.querySelector('.card-pw-timer');
            if (t) t.textContent = _formatMMSS(left);
            if (left <= 60) b.classList.add('is-warn');
            if (left <= 0)  b.style.display = 'none';
        });
    }
    tick();
    setInterval(tick, 1000);
})();
</script>

<?php
$content   = ob_get_clean();
$pageTitle = 'Exam Room Slots';
// College page: the heading is the college name, no subtitle.
$pageHeading = ($mode === 'slots') ? $collegeParam : (($mode === 'roster') ? 'Room Roster' : 'Exam Slots');
// Breadcrumb: Entrance Exam > Exam Slots > College > Room Roster. Proctors land
// straight on their own college's slots page, so the upper levels are only
// parents for managers.
$pageBreadcrumb = [];
if ($mode === 'colleges' && $canManage) {
    $pageBreadcrumb[] = ['label' => 'Entrance Exam', 'to' => '/staff/exam'];
} elseif ($mode === 'slots' && $canManage) {
    $pageBreadcrumb[] = ['label' => 'Entrance Exam', 'to' => '/staff/exam'];
    $pageBreadcrumb[] = ['label' => 'Exam Slots', 'to' => '/staff/exam/slots'];
} elseif ($mode === 'roster' && !empty($slotDetail)) {
    if ($canManage) {
        $pageBreadcrumb[] = ['label' => 'Entrance Exam', 'to' => '/staff/exam'];
        $pageBreadcrumb[] = ['label' => 'Exam Slots', 'to' => '/staff/exam/slots'];
    }
    $pageBreadcrumb[] = ['label' => (string)$slotDetail['department'], 'to' => '/staff/exam/slots?college=' . urlencode($slotDetail['department'])];
}
$pageActions = ($mode === 'roster' && !empty($slotDetail))
    ? ($canManage && !$isPast ? ui_button('Edit slot', ['icon' => 'ic_fluent_edit_24_regular', 'attrs' => ['onclick' => 'openEditExamSlot(' . $editPayload . ')']]) : '')
    : '';
$activeNav = 'exam';
$pageWide  = true; // all three modes use the wide-page container
include VIEWS_PATH . '/layouts/app.php';